const APP_VERSION = 5;
const STATE_KEY = `high-risk-panel-state-v${APP_VERSION}`;
const SESSION_KEY = `high-risk-panel-session-v${APP_VERSION}`;

const METABASE_QUERY = {
  id: 105017,
  title: "live_priority_v4_1_value_aware_2026_08_01",
  url: "https://metabase.basalam.dev/question/105017-live-priority-v4-1-value-aware-2026-08-01",
  expectedColumns: [
    "order_id",
    "scored_at",
    "order_purchase_at",
    "customer_id",
    "vendor_ids",
    "vendor_titles",
    "open_gmv_toman",
    "open_commission_toman",
    "cancellation_probability_pct",
    "priority_pct",
    "risk_band",
    "priority_band",
    "likely_cancel_reason_group",
    "evidence_summary_fa",
    "recommended_action_fa",
    "model_version"
  ]
};

const BACKEND_BASE = window.location.protocol === "file:" ? "http://127.0.0.1:5173" : "";

const money = new Intl.NumberFormat("fa-IR");
const shortNumber = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 1 });

const reasonGroups = {
  customer_cancel_intent: "قصد لغو مشتری",
  vendor_no_response_or_approval: "عدم پاسخ یا تایید vendor",
  inventory_or_availability: "ناموجودی",
  delay_or_shipping: "تاخیر یا ارسال",
  price_or_cost: "قیمت یا هزینه",
  general_historical_risk: "ریسک تاریخی"
};

const terminalStatuses = ["closed_tracking_code", "closed_cancelled", "closed_refunded", "closed_no_action"];

let selectedOrderId = "AV8191";
let activeView = "dashboard";
let activePreset = "all";
let selectedAdminExpertId = "E-101";
let toastTimer = null;
let backendSyncInFlight = false;
let backendSyncAttempted = false;
let state = loadState();
ensureDefaultAccess();
let currentUser = loadSession();

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

function initialState() {
  return {
    version: APP_VERSION,
    dataSource: "sample_local",
    users: [
      { id: "U-ADMIN", username: "admin", password: "admin123", role: "admin", name: "ادمین سیستم" },
      { id: "U-101", username: "ali", password: "1234", role: "expert", expertId: "E-101", name: "علی رستمی" },
      { id: "U-102", username: "maryam", password: "1234", role: "expert", expertId: "E-102", name: "مریم نادری" },
      { id: "U-103", username: "sara", password: "1234", role: "expert", expertId: "E-103", name: "سارا اکبری" }
    ],
    experts: [
      {
        id: "E-101",
        name: "علی رستمی",
        username: "ali",
        status: "active",
        shift: "online",
        capacity: 12,
        openingAmount: 10000000,
        topUps: 0,
        skillTags: ["delay_or_shipping", "vendor_no_response_or_approval"]
      },
      {
        id: "E-102",
        name: "مریم نادری",
        username: "maryam",
        status: "active",
        shift: "online",
        capacity: 10,
        openingAmount: 10000000,
        topUps: 0,
        skillTags: ["inventory_or_availability", "customer_cancel_intent", "price_or_cost"]
      },
      {
        id: "E-103",
        name: "سارا اکبری",
        username: "sara",
        status: "active",
        shift: "online",
        capacity: 9,
        openingAmount: 10000000,
        topUps: 0,
        skillTags: ["price_or_cost", "general_historical_risk"]
      }
    ],
    vendorOwners: {
      "V-441": "E-101",
      "V-224": "E-101",
      "V-918": "E-102",
      "V-311": "E-103"
    },
    orders: [
      {
        orderId: "AV8191",
        customerId: "C-24091",
        vendorId: "V-441",
        vendorTitle: "خانه چوب",
        amount: 8100000,
        commissionToman: 0,
        itemCount: 2,
        ageHours: 18,
        createdAt: "امروز ۰۹:۳۸",
        riskBand: "R1",
        priorityBand: "P1",
        priorityPct: 94,
        reasonGroup: "delay_or_shipping",
        evidenceSummary: "کد رهگیری ندارد، vendor از زمان آماده سازی عبور کرده و مشتری پیام لغو داده است.",
        hasChatSignal: true,
        openStatus: "waiting_vendor",
        trackingStatus: "ندارد",
        assignment: {
          expertId: "E-101",
          status: "in_progress",
          assignedAt: "امروز ۱۰:۰۵",
          reason: "vendor owner",
          isNew: false
        },
        spend: 0,
        deficitPending: 1200000,
        modelVersion: "risk-v0.3-local",
        scoredAt: "امروز ۱۰:۱۲",
        chat: [
          {
            messageId: "M-8821",
            time: "۱۰:۲۸",
            sender: "customer",
            receiver: "expert",
            keywordGroup: "customer_cancel_intent",
            message: "اگر امروز ارسال نمیشه میخوام لغو کنم."
          },
          {
            messageId: "M-8824",
            time: "۱۰:۳۱",
            sender: "vendor",
            receiver: "expert",
            keywordGroup: "delay_or_shipping",
            message: "هنوز امکان ارسال قطعی نداریم."
          }
        ],
        vendorHistory: {
          openOrders: 2,
          cancelRate: 0.21,
          noApproveRate: 0.18,
          oosRate: 0.08,
          delayRate: 0.24,
          avgSeenTime: "۱ ساعت و ۴۰ دقیقه"
        },
        customerHistory: { orderCount: 7, cancelRate: 0.19, avgGmv: 4200000 },
        actions: [
          {
            actorId: "E-101",
            actorName: "علی رستمی",
            type: "پیگیری vendor",
            result: "منتظر پاسخ",
            note: "vendor گفت موجودی نهایی تا ظهر اعلام می شود.",
            at: "امروز ۱۰:۳۴"
          }
        ],
        outcome: {
          status: "manual_review",
          trackingCode: "",
          cancelledAt: "",
          refundAt: "",
          refundAmount: 0,
          systemReason: "",
          expertFinalReason: "",
          reasonMatchStatus: "در انتظار"
        }
      },
      {
        orderId: "AV7619",
        customerId: "C-18104",
        vendorId: "V-224",
        vendorTitle: "نگاران رضوی",
        amount: 12500000,
        commissionToman: 625000,
        itemCount: 1,
        ageHours: 9,
        createdAt: "امروز ۱۲:۰۵",
        riskBand: "R2",
        priorityBand: "P1",
        priorityPct: 88,
        reasonGroup: "inventory_or_availability",
        evidenceSummary: "موجودی محصول قدیمی است و vendor در سفارش های مشابه ناموجودی داشته است.",
        hasChatSignal: false,
        openStatus: "closed_tracking_code",
        trackingStatus: "ثبت شده",
        assignment: {
          expertId: "E-101",
          status: "closed_tracking_code",
          assignedAt: "امروز ۱۲:۲۰",
          reason: "manual admin assignment",
          isNew: true
        },
        spend: 300000,
        deficitPending: 0,
        modelVersion: "risk-v0.3-local",
        scoredAt: "امروز ۱۲:۱۸",
        chat: [],
        vendorHistory: { openOrders: 4, cancelRate: 0.14, noApproveRate: 0.11, oosRate: 0.22, delayRate: 0.07, avgSeenTime: "۴۸ دقیقه" },
        customerHistory: { orderCount: 12, cancelRate: 0.08, avgGmv: 3700000 },
        actions: [
          {
            actorId: "E-101",
            actorName: "علی رستمی",
            type: "تایید موجودی",
            result: "موفق",
            note: "موجودی تایید شد و کد رهگیری ثبت شد.",
            at: "امروز ۱۲:۴۸"
          }
        ],
        outcome: {
          status: "closed_tracking_code",
          trackingCode: "TR-AV7619",
          cancelledAt: "",
          refundAt: "",
          refundAmount: 0,
          systemReason: "",
          expertFinalReason: "موجودی تایید شد",
          reasonMatchStatus: "matched"
        }
      },
      {
        orderId: "AV7744",
        customerId: "C-29001",
        vendorId: "V-224",
        vendorTitle: "نگاران رضوی",
        amount: 6200000,
        commissionToman: 0,
        itemCount: 3,
        ageHours: 31,
        createdAt: "دیروز ۱۶:۴۸",
        riskBand: "R1",
        priorityBand: "P2",
        priorityPct: 79,
        reasonGroup: "vendor_no_response_or_approval",
        evidenceSummary: "سفارش دیده شده اما تایید نشده و میانگین زمان پاسخ vendor از حد مجاز گذشته است.",
        hasChatSignal: true,
        openStatus: "waiting_vendor",
        trackingStatus: "ندارد",
        assignment: {
          expertId: "E-101",
          status: "waiting_vendor",
          assignedAt: "دیروز ۱۷:۱۲",
          reason: "vendor owner",
          isNew: false
        },
        spend: 0,
        deficitPending: 0,
        modelVersion: "risk-v0.3-local",
        scoredAt: "دیروز ۱۷:۰۰",
        chat: [
          {
            messageId: "M-8811",
            time: "دیروز ۱۸:۰۳",
            sender: "expert",
            receiver: "vendor",
            keywordGroup: "vendor_no_response_or_approval",
            message: "لطفا وضعیت تایید سفارش را اعلام کنید."
          }
        ],
        vendorHistory: { openOrders: 4, cancelRate: 0.14, noApproveRate: 0.11, oosRate: 0.22, delayRate: 0.07, avgSeenTime: "۴۸ دقیقه" },
        customerHistory: { orderCount: 4, cancelRate: 0.12, avgGmv: 2100000 },
        actions: [
          {
            actorId: "E-101",
            actorName: "علی رستمی",
            type: "تماس با vendor",
            result: "بی پاسخ",
            note: "یک تماس ناموفق ثبت شد.",
            at: "دیروز ۱۸:۱۰"
          }
        ],
        outcome: { status: "unknown", trackingCode: "", cancelledAt: "", refundAt: "", refundAmount: 0, systemReason: "", expertFinalReason: "", reasonMatchStatus: "نامشخص" }
      },
      {
        orderId: "AV8501",
        customerId: "C-29980",
        vendorId: "V-224",
        vendorTitle: "نگاران رضوی",
        amount: 9800000,
        commissionToman: 0,
        itemCount: 2,
        ageHours: 2,
        createdAt: "امروز ۱۶:۳۵",
        riskBand: "R1",
        priorityBand: "P1",
        priorityPct: 92,
        reasonGroup: "inventory_or_availability",
        evidenceSummary: "سفارش جدید همین vendor است؛ چون vendor owner دارد، فقط با اجرای قانون vendor-owner به همان کارشناس می رود.",
        hasChatSignal: false,
        openStatus: "new",
        trackingStatus: "ندارد",
        assignment: {
          expertId: "",
          status: "unassigned",
          assignedAt: "",
          reason: "vendor owner pending",
          isNew: false
        },
        spend: 0,
        deficitPending: 0,
        modelVersion: "risk-v0.3-local",
        scoredAt: "امروز ۱۶:۳۷",
        chat: [],
        vendorHistory: { openOrders: 4, cancelRate: 0.14, noApproveRate: 0.11, oosRate: 0.22, delayRate: 0.07, avgSeenTime: "۴۸ دقیقه" },
        customerHistory: { orderCount: 5, cancelRate: 0.1, avgGmv: 3100000 },
        actions: [],
        outcome: { status: "unknown", trackingCode: "", cancelledAt: "", refundAt: "", refundAmount: 0, systemReason: "", expertFinalReason: "", reasonMatchStatus: "نامشخص" }
      },
      {
        orderId: "AV8075",
        customerId: "C-11824",
        vendorId: "V-918",
        vendorTitle: "پوشاک آریا",
        amount: 22000000,
        commissionToman: 0,
        itemCount: 6,
        ageHours: 14,
        createdAt: "امروز ۰۸:۵۸",
        riskBand: "R2",
        priorityBand: "P2",
        priorityPct: 73,
        reasonGroup: "price_or_cost",
        evidenceSummary: "اختلاف قیمت ثبت شده و مبلغ سفارش برای اولویت مالی بالا است.",
        hasChatSignal: false,
        openStatus: "needs_admin_review",
        trackingStatus: "ندارد",
        assignment: {
          expertId: "E-102",
          status: "needs_admin_review",
          assignedAt: "امروز ۰۹:۳۰",
          reason: "manual admin assignment",
          isNew: false
        },
        spend: 1850000,
        deficitPending: 2100000,
        modelVersion: "risk-v0.3-local",
        scoredAt: "امروز ۰۹:۱۵",
        chat: [],
        vendorHistory: { openOrders: 3, cancelRate: 0.09, noApproveRate: 0.05, oosRate: 0.04, delayRate: 0.12, avgSeenTime: "۳۴ دقیقه" },
        customerHistory: { orderCount: 18, cancelRate: 0.05, avgGmv: 6900000 },
        actions: [
          {
            actorId: "E-102",
            actorName: "مریم نادری",
            type: "ثبت کسری",
            result: "در انتظار تایید",
            note: "اختلاف قیمت نیازمند بودجه اضافه است.",
            at: "امروز ۰۹:۴۸"
          }
        ],
        outcome: { status: "manual_review", trackingCode: "", cancelledAt: "", refundAt: "", refundAmount: 0, systemReason: "price_issue", expertFinalReason: "", reasonMatchStatus: "در انتظار" }
      },
      {
        orderId: "AV7902",
        customerId: "C-65420",
        vendorId: "V-918",
        vendorTitle: "پوشاک آریا",
        amount: 7200000,
        commissionToman: 0,
        itemCount: 2,
        ageHours: 72,
        createdAt: "سه روز پیش",
        riskBand: "R2",
        priorityBand: "P2",
        priorityPct: 67,
        reasonGroup: "price_or_cost",
        evidenceSummary: "اختلاف قیمت دیر resolve شد و سفارش قبل از کد رهگیری کنسل شد.",
        hasChatSignal: true,
        openStatus: "closed_cancelled",
        trackingStatus: "ندارد",
        assignment: {
          expertId: "E-102",
          status: "closed_cancelled",
          assignedAt: "سه روز پیش",
          reason: "manual admin assignment",
          isNew: false
        },
        spend: 420000,
        deficitPending: 0,
        modelVersion: "risk-v0.3-local",
        scoredAt: "سه روز پیش",
        chat: [],
        vendorHistory: { openOrders: 3, cancelRate: 0.09, noApproveRate: 0.05, oosRate: 0.04, delayRate: 0.12, avgSeenTime: "۳۴ دقیقه" },
        customerHistory: { orderCount: 6, cancelRate: 0.2, avgGmv: 2800000 },
        actions: [
          {
            actorId: "E-102",
            actorName: "مریم نادری",
            type: "تماس با مشتری",
            result: "کنسل شد",
            note: "مشتری جایگزین را نپذیرفت.",
            at: "دو روز پیش"
          }
        ],
        outcome: { status: "closed_cancelled", trackingCode: "", cancelledAt: "دو روز پیش", refundAt: "", refundAmount: 0, systemReason: "price_issue", expertFinalReason: "اختلاف قیمت", reasonMatchStatus: "matched" }
      },
      {
        orderId: "AV8302",
        customerId: "C-55219",
        vendorId: "V-311",
        vendorTitle: "چرم مانا",
        amount: 4300000,
        commissionToman: 215000,
        itemCount: 1,
        ageHours: 42,
        createdAt: "دیروز ۰۸:۱۲",
        riskBand: "R3",
        priorityBand: "P3",
        priorityPct: 44,
        reasonGroup: "general_historical_risk",
        evidenceSummary: "ریسک تاریخی vendor بدون evidence live روشن؛ snapshot برای پایش نگه داشته شده است.",
        hasChatSignal: false,
        openStatus: "closed_tracking_code",
        trackingStatus: "ثبت شده",
        assignment: {
          expertId: "E-103",
          status: "closed_tracking_code",
          assignedAt: "دیروز ۰۹:۰۰",
          reason: "manual admin assignment",
          isNew: false
        },
        spend: 980000,
        deficitPending: 0,
        modelVersion: "risk-v0.3-local",
        scoredAt: "دیروز ۰۸:۵۰",
        chat: [],
        vendorHistory: { openOrders: 1, cancelRate: 0.18, noApproveRate: 0.06, oosRate: 0.03, delayRate: 0.11, avgSeenTime: "۱ ساعت" },
        customerHistory: { orderCount: 3, cancelRate: 0, avgGmv: 3100000 },
        actions: [
          {
            actorId: "E-103",
            actorName: "سارا اکبری",
            type: "پایش",
            result: "کد رهگیری ثبت شد",
            note: "بدون هزینه اضافه بسته شد.",
            at: "دیروز ۱۲:۰۰"
          }
        ],
        outcome: { status: "closed_tracking_code", trackingCode: "TR-AV8302", cancelledAt: "", refundAt: "", refundAmount: 0, systemReason: "", expertFinalReason: "عبور موفق", reasonMatchStatus: "not_applicable" }
      },
      {
        orderId: "AV8422",
        customerId: "C-77118",
        vendorId: "V-607",
        vendorTitle: "لوازم روشن",
        amount: 15600000,
        commissionToman: 0,
        itemCount: 4,
        ageHours: 5,
        createdAt: "امروز ۱۵:۰۵",
        riskBand: "R1",
        priorityBand: "P1",
        priorityPct: 91,
        reasonGroup: "customer_cancel_intent",
        evidenceSummary: "پیام مشتری شامل درخواست لغو است و سفارش هنوز کد رهگیری ندارد؛ این vendor هنوز owner ندارد.",
        hasChatSignal: true,
        openStatus: "new",
        trackingStatus: "ندارد",
        assignment: {
          expertId: "",
          status: "unassigned",
          assignedAt: "",
          reason: "no vendor owner",
          isNew: false
        },
        spend: 0,
        deficitPending: 0,
        modelVersion: "risk-v0.3-local",
        scoredAt: "امروز ۱۵:۱۰",
        chat: [
          {
            messageId: "M-8902",
            time: "۱۵:۰۸",
            sender: "customer",
            receiver: "support",
            keywordGroup: "customer_cancel_intent",
            message: "اگر امروز قطعی نمیشه نمیخوام ادامه بدم."
          }
        ],
        vendorHistory: { openOrders: 1, cancelRate: 0.07, noApproveRate: 0.03, oosRate: 0.02, delayRate: 0.06, avgSeenTime: "۲۲ دقیقه" },
        customerHistory: { orderCount: 9, cancelRate: 0.24, avgGmv: 5800000 },
        actions: [],
        outcome: { status: "unknown", trackingCode: "", cancelledAt: "", refundAt: "", refundAmount: 0, systemReason: "", expertFinalReason: "", reasonMatchStatus: "نامشخص" }
      }
    ],
    deficits: [
      { id: "D-104", orderId: "AV8191", expertId: "E-101", vendorId: "V-441", amount: 1200000, reason: "هزینه ارسال جایگزین", note: "برای جلوگیری از لغو مشتری", status: "pending", createdAt: "امروز ۱۰:۴۲" },
      { id: "D-109", orderId: "AV8075", expertId: "E-102", vendorId: "V-918", amount: 2100000, reason: "اختلاف قیمت", note: "نیازمند تایید سرپرست", status: "pending", createdAt: "امروز ۰۹:۴۸" }
    ],
    keywordRules: [
      { id: "K-1", keyword: "میخوام لغو کنم", group: "customer_cancel_intent", severity: "high", active: true, version: 3 },
      { id: "K-2", keyword: "موجود نیست", group: "inventory_or_availability", severity: "high", active: true, version: 2 },
      { id: "K-3", keyword: "ارسال نکرد", group: "delay_or_shipping", severity: "medium", active: true, version: 2 }
    ],
    notifications: [
      { id: "N-101", expertId: "E-101", orderId: "AV7619", message: "سفارش جدید به شما اختصاص داده شد.", unread: true, at: "امروز ۱۲:۲۰" }
    ],
    auditLogs: [
      { actor: "system", action: "risk_snapshot_ingestion", entity: "AV8422", at: "امروز ۱۵:۱۰" },
      { actor: "admin.local", action: "expert.created", entity: "E-101", at: "دمو اولیه" }
    ]
  };
}

function demoState() {
  const fresh = initialState();
  fresh.version = APP_VERSION;
  fresh.dataSource = "sample_local";
  fresh.dataSourceMeta = {
    queryId: METABASE_QUERY.id,
    queryTitle: METABASE_QUERY.title,
    importedAt: "",
    rowCount: fresh.orders.length,
    fileName: "",
    note: "داده نمونه فقط برای تست تجربه پنل است و مبنای تصمیم عملیاتی نیست."
  };
  return fresh;
}

function metabaseReadyState(previousState = null) {
  const demo = initialState();
  return {
    ...demo,
    version: APP_VERSION,
    dataSource: "metabase_pending",
    dataSourceMeta: {
      queryId: METABASE_QUERY.id,
      queryTitle: METABASE_QUERY.title,
      importedAt: "",
      rowCount: 0,
      fileName: "",
      note: "کوئری Metabase دریافت شده؛ هنوز خروجی CSV/JSON همان question وارد نشده است."
    },
    users: previousState?.users?.length ? previousState.users : demo.users,
    experts: previousState?.experts?.length ? previousState.experts : demo.experts,
    vendorOwners: previousState?.vendorOwners || {},
    orders: [],
    deficits: [],
    notifications: [],
    auditLogs: [
      {
        actor: "system",
        action: "metabase_query_schema.loaded",
        entity: `question-${METABASE_QUERY.id}`,
        at: nowText()
      }
    ]
  };
}

function loadState() {
  try {
    const stored = JSON.parse(localStorage.getItem(STATE_KEY));
    if (stored?.version === APP_VERSION) return stored;
  } catch (error) {
    console.warn(error);
  }
  const fresh = metabaseReadyState();
  localStorage.setItem(STATE_KEY, JSON.stringify(fresh));
  return fresh;
}

function saveState() {
  localStorage.setItem(STATE_KEY, JSON.stringify(state));
}

function ensureDefaultAccess() {
  state.users ||= [];
  state.experts ||= [];
  state.orders ||= [];
  state.deficits ||= [];
  state.keywordRules ||= [];
  state.notifications ||= [];
  state.auditLogs ||= [];
  state.vendorOwners ||= {};
  state.dataSource ||= "metabase_pending";
  state.dataSourceMeta ||= {
    queryId: METABASE_QUERY.id,
    queryTitle: METABASE_QUERY.title,
    importedAt: "",
    rowCount: state.orders.length,
    fileName: "",
    note: "وضعیت منبع داده مشخص نشده است."
  };

  const hasAdmin = state.users.some((user) => user.username === "admin");
  if (!hasAdmin) {
    state.users.unshift({ id: "U-ADMIN", username: "admin", password: "admin123", role: "admin", name: "ادمین سیستم" });
  }

  state.experts.forEach((expert, index) => {
    if (!expert.username) expert.username = `expert${index + 1}`;
    const hasUser = state.users.some((user) => user.expertId === expert.id);
    if (!hasUser) {
      state.users.push({
        id: `U-${expert.id}`,
        username: expert.username,
        password: "1234",
        role: "expert",
        expertId: expert.id,
        name: expert.name
      });
    }
  });

  saveState();
}

function loadSession() {
  try {
    const stored = JSON.parse(sessionStorage.getItem(SESSION_KEY));
    if (!stored) return null;
    return state.users.find((user) => user.id === stored.id) || null;
  } catch (error) {
    return null;
  }
}

function saveSession(user) {
  currentUser = user;
  sessionStorage.setItem(SESSION_KEY, JSON.stringify({ id: user.id }));
}

function clearSession() {
  currentUser = null;
  sessionStorage.removeItem(SESSION_KEY);
}

function resetDemoData() {
  state = demoState();
  saveState();
  clearSession();
  selectedOrderId = "AV8191";
  activeView = "dashboard";
  selectedAdminExpertId = "E-101";
  renderReasonOptions();
  render();
  showToast("داده نمونه بازنشانی شد. حالا با admin / admin123 وارد شو.");
}

function toman(value) {
  return `${money.format(Math.round(value || 0))} تومان`;
}

function amountShort(value) {
  if (value >= 1000000) return `${shortNumber.format(value / 1000000)}M`;
  if (value >= 1000) return `${shortNumber.format(value / 1000)}K`;
  return money.format(value || 0);
}

function pct(value) {
  return `${money.format(Math.round((value || 0) * 100))}%`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function nowText() {
  return "همین الان";
}

function isAdmin() {
  return currentUser?.role === "admin";
}

function currentExpertId() {
  return currentUser?.role === "expert" ? currentUser.expertId : null;
}

function getExpert(expertId) {
  return state.experts.find((expert) => expert.id === expertId);
}

function getExpertName(expertId) {
  return getExpert(expertId)?.name || "تخصیص نشده";
}

function getOrder(orderId = selectedOrderId) {
  const visible = visibleOrders();
  return state.orders.find((order) => order.orderId === orderId) || visible[0] || state.orders[0];
}

function isOpenOrder(order) {
  return !terminalStatuses.includes(order.openStatus);
}

function computeExpertStats(expertId) {
  const expert = getExpert(expertId);
  const assignedOrders = state.orders.filter((order) => order.assignment.expertId === expertId);
  const openOrders = assignedOrders.filter(isOpenOrder);
  const successfulOrders = assignedOrders.filter((order) => order.outcome.status === "closed_tracking_code");
  const canceledOrders = assignedOrders.filter((order) => order.outcome.status === "closed_cancelled");
  const refundedOrders = assignedOrders.filter((order) => order.outcome.status === "closed_refunded");
  const creditSpent = assignedOrders.reduce((sum, order) => sum + (order.spend || 0), 0);
  const commission = assignedOrders.reduce((sum, order) => sum + (order.commissionToman || 0), 0);
  const pendingDeficit = state.deficits
    .filter((deficit) => deficit.expertId === expertId && deficit.status === "pending")
    .reduce((sum, deficit) => sum + deficit.amount, 0);
  const opening = expert?.openingAmount || 0;
  const topUps = expert?.topUps || 0;

  return {
    assignedCount: assignedOrders.length,
    openCount: openOrders.length,
    successCount: successfulOrders.length,
    canceledCount: canceledOrders.length,
    refundedCount: refundedOrders.length,
    creditSpent,
    commission,
    pendingDeficit,
    balance: opening + topUps - creditSpent,
    orders: assignedOrders
  };
}

function visibleOrders() {
  if (isAdmin()) return state.orders;
  const expertId = currentExpertId();
  return state.orders.filter((order) => order.assignment.expertId === expertId);
}

function riskBadge(order) {
  const riskText = { R1: "R1 Critical", R2: "R2 High", R3: "R3 Medium", R4: "R4 Watch", R5: "R5 Low" }[order.riskBand] || order.riskBand || "Risk";
  return `<span class="badge risk-${String(order.riskBand || "R5").toLowerCase()}">${riskText}</span>`;
}

function statusBadge(status) {
  const text = {
    new: "جدید",
    in_progress: "در حال اقدام",
    waiting_vendor: "انتظار vendor",
    waiting_customer: "انتظار مشتری",
    needs_admin_review: "نیازمند بررسی",
    monitor: "مانیتور",
    unassigned: "بدون کارشناس",
    closed_tracking_code: "موفق",
    closed_cancelled: "کنسل شد",
    closed_refunded: "ریفاند شد",
    manual_review: "بازبینی دستی",
    unknown: "نامشخص",
    pending: "در انتظار تایید",
    approved: "تایید شده",
    rejected: "رد شده"
  }[status] || status;
  const tone = {
    new: "status-info",
    in_progress: "status-ok",
    waiting_vendor: "status-warn",
    waiting_customer: "status-warn",
    needs_admin_review: "status-danger",
    monitor: "status-info",
    unassigned: "status-danger",
    closed_tracking_code: "status-ok",
    closed_cancelled: "status-danger",
    closed_refunded: "status-warn",
    manual_review: "status-warn",
    pending: "status-warn",
    approved: "status-ok",
    rejected: "status-danger"
  }[status] || "";
  return `<span class="badge ${tone}">${text}</span>`;
}

function addAudit(action, entity, actor = currentUser?.username || "system") {
  state.auditLogs.push({ actor, action, entity, at: nowText() });
}

function addNotification(expertId, orderId, message) {
  state.notifications.push({
    id: `N-${Date.now()}`,
    expertId,
    orderId,
    message,
    unread: true,
    at: nowText()
  });
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3600);
}

function dataSourceLabel() {
  if (state.dataSource === "backend_query") return "داده زنده بک‌اند";
  if (state.dataSource === "metabase_import") return "داده واقعی Metabase";
  if (state.dataSource === "sample_local") return "داده نمونه";
  return "منتظر خروجی Metabase";
}

function dataSourceEyebrow() {
  if (state.dataSource === "backend_query") {
    return `داده ها از بک‌اند همین محصول و query ${METABASE_QUERY.id} خوانده شده اند؛ اقدام ها در نسخه لوکال داخل مرورگر ذخیره می شوند.`;
  }
  if (state.dataSource === "metabase_import") {
    return `داده ها از خروجی Metabase question ${METABASE_QUERY.id} وارد شده اند؛ تغییرات عملیاتی در همین مرورگر ذخیره می شود.`;
  }
  if (state.dataSource === "sample_local") {
    return "داده ها نمونه هستند و فقط برای تست تجربه پنل استفاده می شوند.";
  }
  return "کوئری Metabase دریافت شده؛ برای نمایش سفارش واقعی باید خروجی CSV یا JSON همان question را وارد کنی.";
}

function normalizeHeader(value) {
  return String(value ?? "")
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase();
}

function toEnglishDigits(value) {
  return String(value ?? "")
    .replace(/[۰-۹]/g, (digit) => "۰۱۲۳۴۵۶۷۸۹".indexOf(digit))
    .replace(/[٠-٩]/g, (digit) => "٠١٢٣٤٥٦٧٨٩".indexOf(digit));
}

function toNumber(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const normalized = toEnglishDigits(value).replace(/[%٬,\s]/g, "");
  if (!normalized) return 0;
  const number = Number(normalized);
  return Number.isFinite(number) ? number : 0;
}

function toBoolean(value) {
  if (typeof value === "boolean") return value;
  const normalized = String(value ?? "").trim().toLowerCase();
  return ["1", "true", "yes", "y", "بله"].includes(normalized);
}

function ratioFromPercent(value) {
  const number = toNumber(value);
  return number > 1 ? number / 100 : number;
}

function rowValue(row, ...keys) {
  for (const key of keys) {
    const normalized = normalizeHeader(key);
    if (Object.prototype.hasOwnProperty.call(row, normalized) && row[normalized] !== null && row[normalized] !== undefined && row[normalized] !== "") {
      return row[normalized];
    }
  }
  return "";
}

function textValue(row, ...keys) {
  return String(rowValue(row, ...keys) ?? "").trim();
}

function normalizeMetabaseRow(row) {
  return Object.fromEntries(Object.entries(row || {}).map(([key, value]) => [normalizeHeader(key), value]));
}

function parseCsvRows(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        cell += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === "," && !inQuotes) {
      row.push(cell);
      cell = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell);
      if (row.some((item) => String(item).trim() !== "")) rows.push(row);
      row = [];
      cell = "";
      continue;
    }

    cell += char;
  }

  row.push(cell);
  if (row.some((item) => String(item).trim() !== "")) rows.push(row);
  return rows;
}

function parseCsvObjects(text) {
  const rows = parseCsvRows(text);
  if (!rows.length) return [];
  const headers = rows[0].map(normalizeHeader);
  return rows.slice(1).map((row) => {
    const record = {};
    headers.forEach((header, index) => {
      if (header) record[header] = row[index] ?? "";
    });
    return record;
  });
}

function rowsFromJson(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  if (Array.isArray(value?.results)) return value.results;

  const tabular = Array.isArray(value?.data?.rows) ? value.data : Array.isArray(value?.rows) ? value : null;
  if (tabular) {
    const headers = (tabular.cols || tabular.columns || []).map((column) => {
      if (typeof column === "string") return column;
      return column.name || column.display_name || column.field_ref?.at?.(-1) || "";
    });
    return tabular.rows.map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index]])));
  }

  throw new Error("ساختار JSON خروجی Metabase قابل خواندن نیست.");
}

function parseMetabaseExport(text, fileName = "") {
  const trimmed = text.trim();
  if (!trimmed) return [];
  if (fileName.toLowerCase().endsWith(".json") || trimmed.startsWith("[") || trimmed.startsWith("{")) {
    return rowsFromJson(JSON.parse(trimmed)).map(normalizeMetabaseRow);
  }
  return parseCsvObjects(text).map(normalizeMetabaseRow);
}

function firstVendorId(value) {
  return vendorIdList(value)[0] || "vendor_unknown";
}

function vendorIdList(value) {
  return String(value || "")
    .split(/[,\|]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function orderVendorIds(order) {
  return order.vendorIds?.length ? order.vendorIds : vendorIdList(order.vendorId);
}

function normalizeRiskBand(value, probabilityPct) {
  const text = String(value || "").toUpperCase();
  if (text.includes("R1")) return "R1";
  if (text.includes("R2")) return "R2";
  if (text.includes("R3")) return "R3";
  if (text.includes("R4")) return "R4";
  if (text.includes("R5")) return "R5";
  const pctValue = toNumber(probabilityPct);
  if (pctValue >= 70) return "R1";
  if (pctValue >= 40) return "R2";
  if (pctValue >= 20) return "R3";
  if (pctValue >= 10) return "R4";
  return "R5";
}

function normalizePriorityBand(value, priorityPct) {
  const text = String(value || "").toUpperCase();
  if (text.includes("P1")) return "P1";
  if (text.includes("P2")) return "P2";
  if (text.includes("P3")) return "P3";
  if (text.includes("P4")) return "P4";
  const pctValue = toNumber(priorityPct);
  if (pctValue >= 95) return "P1";
  if (pctValue >= 85) return "P2";
  if (pctValue >= 65) return "P3";
  return "P4";
}

function normalizeReasonGroup(value) {
  const text = String(value || "").toLowerCase();
  if (text.includes("customer") || text.includes("communication")) return "customer_cancel_intent";
  if (text.includes("vendor_no") || text.includes("approval") || text.includes("response")) return "vendor_no_response_or_approval";
  if (text.includes("inventory") || text.includes("availability") || text.includes("stock")) return "inventory_or_availability";
  if (text.includes("delay") || text.includes("shipping") || text.includes("send")) return "delay_or_shipping";
  if (text.includes("price") || text.includes("cost")) return "price_or_cost";
  return "general_historical_risk";
}

function buildMetabaseChat(row, orderId, reasonGroup) {
  const chatMessages = toNumber(rowValue(row, "chat_messages"));
  const signalCounts = [
    ["cancel_keyword_messages", "کلمات لغو"],
    ["inventory_keyword_messages", "کلمات موجودی"],
    ["shipping_keyword_messages", "کلمات ارسال/تاخیر"],
    ["price_keyword_messages", "کلمات قیمت"],
    ["explicit_cancel_phrase_messages", "درخواست صریح لغو"],
    ["explicit_stockout_phrase_messages", "ناموجودی صریح"],
    ["vendor_inability_phrase_messages", "ناتوانی vendor"],
    ["no_send_or_no_response_phrase_messages", "عدم ارسال/پاسخ"],
    ["replacement_or_change_phrase_messages", "تغییر یا جایگزینی"]
  ]
    .map(([key, label]) => [label, toNumber(rowValue(row, key))])
    .filter(([, count]) => count > 0);

  if (!chatMessages && !signalCounts.length) return [];

  const summary = [
    chatMessages ? `${money.format(chatMessages)} پیام چت در بازه مدل` : "",
    ...signalCounts.map(([label, count]) => `${label}: ${money.format(count)}`)
  ]
    .filter(Boolean)
    .join("، ");

  return [
    {
      messageId: `MB-${orderId}`,
      time: "خروجی Metabase",
      sender: "model",
      receiver: "expert",
      keywordGroup: reasonGroup,
      message: summary
    }
  ];
}

function mapMetabaseRowToOrder(sourceRow) {
  const row = normalizeMetabaseRow(sourceRow);
  const orderId = textValue(row, "order_id");
  if (!orderId) return null;

  const vendorIds = textValue(row, "vendor_ids", "vendor_id");
  const vendorId = firstVendorId(vendorIds);
  const vendorTitle = textValue(row, "vendor_titles", "vendor_title") || vendorId;
  const amount = toNumber(rowValue(row, "open_gmv_toman", "order_gmv_toman"));
  const commissionToman = toNumber(rowValue(row, "open_commission_toman", "order_commission_toman"));
  const priorityPct = Math.max(1, Math.min(100, Math.round(toNumber(rowValue(row, "priority_pct")) || 1)));
  const cancellationProbabilityPct = toNumber(rowValue(row, "cancellation_probability_pct"));
  const reasonGroup = normalizeReasonGroup(textValue(row, "likely_cancel_reason_group"));
  const evidenceSummary =
    textValue(row, "evidence_summary_fa") ||
    textValue(row, "likely_cancel_reason_fa") ||
    textValue(row, "recommended_action_fa") ||
    "در خروجی Metabase evidence متنی ثبت نشده است.";

  const hasChatSignal =
    toNumber(rowValue(row, "chat_messages")) > 0 ||
    toNumber(rowValue(row, "cancel_keyword_messages")) > 0 ||
    toNumber(rowValue(row, "inventory_keyword_messages")) > 0 ||
    toNumber(rowValue(row, "shipping_keyword_messages")) > 0 ||
    toNumber(rowValue(row, "price_keyword_messages")) > 0 ||
    toBoolean(rowValue(row, "has_unanswered_customer_chat"));

  return {
    orderId,
    customerId: textValue(row, "customer_id") || "-",
    vendorId,
    vendorIds: vendorIdList(vendorIds),
    vendorTitle,
    amount,
    commissionToman,
    itemCount: toNumber(rowValue(row, "open_item_rows", "open_units", "open_product_count")) || 1,
    ageHours: Math.round(toNumber(rowValue(row, "order_age_hours"))),
    createdAt: textValue(row, "order_purchase_at") || "-",
    riskBand: normalizeRiskBand(textValue(row, "risk_band"), cancellationProbabilityPct),
    priorityBand: normalizePriorityBand(textValue(row, "priority_band"), priorityPct),
    priorityPct,
    reasonGroup,
    evidenceSummary,
    hasChatSignal,
    openStatus: "unassigned",
    trackingStatus: "ندارد",
    assignment: {
      expertId: "",
      status: "unassigned",
      assignedAt: "",
      reason: state.vendorOwners[vendorId] ? "vendor owner pending" : "no vendor owner",
      isNew: false
    },
    spend: 0,
    deficitPending: 0,
    modelVersion: textValue(row, "model_version") || METABASE_QUERY.title,
    scoredAt: textValue(row, "scored_at") || "-",
    recommendedAction: textValue(row, "recommended_action_fa"),
    actionQueue: textValue(row, "action_queue"),
    interventionMode: textValue(row, "intervention_mode"),
    interventionRequired: toBoolean(rowValue(row, "intervention_required")),
    metabase: {
      riskPercentile: toNumber(rowValue(row, "risk_percentile")),
      businessImportancePct: toNumber(rowValue(row, "business_importance_pct")),
      cancellationProbabilityPct,
      expectedCancelledGmvToman: toNumber(rowValue(row, "expected_cancelled_gmv_toman")),
      expectedLostCommissionToman: toNumber(rowValue(row, "expected_lost_commission_toman")),
      openVendorCount: toNumber(rowValue(row, "open_vendor_count")),
      openProductCount: toNumber(rowValue(row, "open_product_count")),
      openCommissionRatePct: toNumber(rowValue(row, "open_commission_rate_pct")),
      scoringMode: textValue(row, "scoring_mode")
    },
    chat: buildMetabaseChat(row, orderId, reasonGroup),
    vendorHistory: {
      openOrders: toNumber(rowValue(row, "open_vendor_count")) || 1,
      cancelRate: ratioFromPercent(rowValue(row, "max_vendor_historical_cancel_rate_pct")),
      noApproveRate: ratioFromPercent(rowValue(row, "max_vendor_historical_no_approve_rate_pct")),
      oosRate: ratioFromPercent(rowValue(row, "max_vendor_historical_oos_rate_pct")),
      delayRate: 0,
      avgSeenTime: "-"
    },
    customerHistory: { orderCount: 0, cancelRate: 0, avgGmv: 0 },
    actions: [],
    outcome: {
      status: "unknown",
      trackingCode: "",
      cancelledAt: "",
      refundAt: "",
      refundAmount: 0,
      systemReason: textValue(row, "likely_cancel_reason_group"),
      expertFinalReason: "",
      reasonMatchStatus: "نامشخص"
    },
    rawMetabaseRow: row
  };
}

function mergeImportedOrders(importedOrders) {
  const existingById = new Map(state.orders.map((order) => [order.orderId, order]));
  return importedOrders.map((order) => {
    const existing = existingById.get(order.orderId);
    if (!existing) return order;
    return {
      ...order,
      assignment: existing.assignment?.expertId ? existing.assignment : order.assignment,
      openStatus: existing.assignment?.expertId ? existing.openStatus : order.openStatus,
      spend: existing.spend || 0,
      deficitPending: existing.deficitPending || 0,
      actions: existing.actions || [],
      outcome: existing.outcome || order.outcome,
      commissionToman: existing.commissionToman || order.commissionToman
    };
  });
}

function clearOperationalData() {
  state = metabaseReadyState(state);
  saveState();
  selectedOrderId = "";
  activeView = "admin";
  renderReasonOptions();
  render();
  setView("admin");
  showToast("سفارش ها پاک شد؛ پنل منتظر خروجی واقعی Metabase است.");
}

async function handleMetabaseImport(event) {
  event.preventDefault();
  const form = event.target;
  const data = new FormData(form);
  const file = data.get("metabaseFile");

  if (!file || !file.size) {
    showToast("فایل خروجی Metabase را انتخاب کن.");
    return;
  }

  try {
    const rows = parseMetabaseExport(await file.text(), file.name);
    const mappedOrders = rows.map(mapMetabaseRowToOrder).filter(Boolean);
    if (!mappedOrders.length) {
      showToast("در فایل، ردیف معتبر با ستون order_id پیدا نشد.");
      return;
    }

    state.orders = mergeImportedOrders(mappedOrders);
    state.deficits = state.deficits.filter((deficit) => state.orders.some((order) => order.orderId === deficit.orderId));
    state.notifications = [];
    state.dataSource = "metabase_import";
    state.dataSourceMeta = {
      queryId: METABASE_QUERY.id,
      queryTitle: METABASE_QUERY.title,
      importedAt: nowText(),
      rowCount: state.orders.length,
      fileName: file.name,
      note: "این سفارش ها از خروجی import شده همین گزارش Metabase آمده اند؛ اقدام ها و تخصیص ها همچنان لوکال ذخیره می شوند."
    };
    addAudit("metabase_export.imported", `${file.name} | ${state.orders.length} rows`);

    if (data.get("applyVendorOwner") === "on") applyVendorOwnerAssignments();

    selectedOrderId = visibleOrders()[0]?.orderId || state.orders[0]?.orderId || "";
    saveState();
    form.reset();
    render();
    setView("admin");
    showToast(`${money.format(state.orders.length)} سفارش واقعی از خروجی Metabase وارد شد.`);
  } catch (error) {
    console.error(error);
    showToast(error.message || "فایل خروجی Metabase خوانده نشد.");
  }
}

async function syncBackendOrders({ silent = false } = {}) {
  if (backendSyncInFlight) return;
  backendSyncInFlight = true;

  try {
    const response = await fetch(`${BACKEND_BASE}/api/orders?limit=5000`, { cache: "no-store" });
    const payload = await response.json().catch(() => ({}));

    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `Backend returned ${response.status}`);
    }

    const mappedOrders = (payload.rows || []).map(mapMetabaseRowToOrder).filter(Boolean);
    if (!mappedOrders.length) {
      throw new Error("بک‌اند پاسخ داد اما ردیف سفارش معتبر نداشت.");
    }

    state.orders = mergeImportedOrders(mappedOrders);
    state.deficits = state.deficits.filter((deficit) => state.orders.some((order) => order.orderId === deficit.orderId));
    state.notifications = [];
    state.dataSource = "backend_query";
    state.dataSourceMeta = {
      queryId: payload.queryId || METABASE_QUERY.id,
      queryTitle: payload.queryTitle || METABASE_QUERY.title,
      importedAt: nowText(),
      rowCount: state.orders.length,
      fileName: `backend:${payload.provider || "query"}`,
      note: `این سفارش ها از endpoint بک‌اند /api/orders آمده اند. provider فعلی: ${payload.provider || "query"}.`
    };
    applyVendorOwnerAssignments();
    addAudit("backend_query.synced", `${state.orders.length} rows`);
    saveState();
    selectedOrderId = visibleOrders()[0]?.orderId || state.orders[0]?.orderId || "";
    render();
    setView(activeView);
    if (!silent) showToast(`${money.format(state.orders.length)} سفارش از بک‌اند بروزرسانی شد.`);
  } catch (error) {
    console.warn(error);
    if (/credential|missing|failed|503/i.test(error.message || "")) {
      state.orders = [];
      state.deficits = [];
      state.notifications = [];
      state.dataSource = "metabase_pending";
      state.dataSourceMeta = {
        queryId: METABASE_QUERY.id,
        queryTitle: METABASE_QUERY.title,
        importedAt: nowText(),
        rowCount: 0,
        fileName: "",
        note: `اتصال زنده به بک‌اند برقرار نیست: ${error.message}`
      };
      selectedOrderId = "";
      saveState();
      render();
      setView(activeView);
    }
    if (!silent) showToast(`اتصال بک‌اند برقرار نشد: ${error.message}`);
  } finally {
    backendSyncInFlight = false;
  }
}

function renderReasonOptions() {
  const select = $("#reasonFilter");
  if (!select) return;
  const selected = select.value || "all";
  select.innerHTML = `<option value="all">همه</option>${Object.entries(reasonGroups)
    .map(([value, label]) => `<option value="${value}">${label}</option>`)
    .join("")}`;
  select.value = selected;
}

function filteredOrders() {
  const search = $("#searchInput")?.value.trim().toLowerCase() || "";
  const risk = $("#riskFilter")?.value || "all";
  const reason = $("#reasonFilter")?.value || "all";
  const chatOnly = $("#chatOnlyFilter")?.checked || false;
  const deficitOnly = $("#deficitOnlyFilter")?.checked || false;

  return visibleOrders()
    .filter((order) => {
      const haystack = [order.orderId, order.customerId, order.vendorId, order.vendorTitle, order.reasonGroup, reasonGroups[order.reasonGroup], order.evidenceSummary]
        .join(" ")
        .toLowerCase();
      return (
        (!search || haystack.includes(search)) &&
        (activePreset !== "p1" || order.priorityBand === "P1") &&
        (activePreset !== "new" || order.assignment.isNew) &&
        (risk === "all" || order.riskBand === risk) &&
        (reason === "all" || order.reasonGroup === reason) &&
        (!chatOnly || order.hasChatSignal) &&
        (!deficitOnly || order.deficitPending > 0)
      );
    })
    .sort((a, b) => {
      const riskRank = { R1: 5, R2: 4, R3: 3, R4: 2, R5: 1 };
      const priorityRank = { P1: 4, P2: 3, P3: 2, P4: 1 };
      return (
        Number(b.assignment.isNew) - Number(a.assignment.isNew) ||
        (priorityRank[b.priorityBand] || 0) - (priorityRank[a.priorityBand] || 0) ||
        (riskRank[b.riskBand] || 0) - (riskRank[a.riskBand] || 0) ||
        b.ageHours - a.ageHours ||
        b.amount - a.amount
      );
    });
}

function renderShell() {
  const appShell = $("#appShell");
  const loginScreen = $("#loginScreen");
  const loggedIn = Boolean(currentUser);
  loginScreen.classList.toggle("is-hidden", loggedIn);
  appShell.classList.toggle("is-hidden", !loggedIn);

  if (!loggedIn) return;

  $$("[data-admin-only]").forEach((element) => {
    element.classList.toggle("is-hidden", !isAdmin());
  });

  $("#roleLabel").textContent = isAdmin() ? "ادمین" : "کارشناس";
  $("#currentUserPill").textContent = currentUser.name;
  $(".sidebar-footer span:last-child").textContent = dataSourceLabel();
  $(".env-pill").textContent = dataSourceLabel();
  $("#pageEyebrow").textContent = dataSourceEyebrow();
  $("#dashboardHeading").textContent = isAdmin() ? "داشبورد ادمین" : "داشبورد کارشناس عملیات";
  $("#dashboardSubheading").textContent = isAdmin()
    ? "نمای همه سفارش ها، تخصیص دستی و کنترل vendor owner"
    : "سفارش های اختصاص داده شده، سفارش های جدید و ثبت اقدام";
}

function renderMetrics() {
  const orders = visibleOrders();
  const openOrders = orders.filter(isOpenOrder);
  const unassigned = state.orders.filter((order) => isOpenOrder(order) && !order.assignment.expertId).length;
  const pendingDeficit = state.deficits.filter((deficit) => deficit.status === "pending").reduce((sum, deficit) => sum + deficit.amount, 0);

  let cards;
  if (isAdmin()) {
    const totalStats = state.experts.map((expert) => computeExpertStats(expert.id));
    cards = [
      ["کارشناس فعال", money.format(state.experts.filter((expert) => expert.status === "active").length), "teal"],
      ["سفارش باز", money.format(openOrders.length), "blue"],
      ["بدون کارشناس", money.format(unassigned), "red"],
      ["مصرف اعتبار", toman(totalStats.reduce((sum, item) => sum + item.creditSpent, 0)), "amber"],
      ["کمیسیون ثبت شده", toman(totalStats.reduce((sum, item) => sum + item.commission, 0)), "teal"]
    ];
  } else {
    const stats = computeExpertStats(currentExpertId());
    const newCount = orders.filter((order) => order.assignment.isNew).length;
    cards = [
      ["مانده اعتبار", toman(stats.balance), "teal"],
      ["سفارش باز من", money.format(stats.openCount), "blue"],
      ["سفارش جدید", money.format(newCount), "red"],
      ["موفق / کنسل", `${money.format(stats.successCount)} / ${money.format(stats.canceledCount)}`, "amber"],
      ["کمیسیون من", toman(stats.commission), "teal"]
    ];
  }

  $("#metricStrip").innerHTML = cards
    .map(
      ([label, value, tone]) => `
        <article class="metric-card" data-tone="${tone}">
          <small>${label}</small>
          <strong>${value}</strong>
        </article>
      `
    )
    .join("");
}

function renderOrdersTable() {
  const rows = filteredOrders();
  const body = $("#ordersBody");
  body.innerHTML = rows
    .map((order) => {
      const expert = getExpert(order.assignment.expertId);
      return `
        <tr class="${order.orderId === selectedOrderId ? "is-selected" : ""}">
          <td>
            <button class="order-link" type="button" data-select-order="${order.orderId}">
              <span class="latin">#${order.orderId}</span>
            </button>
            <div class="muted">${order.ageHours} ساعت</div>
          </td>
          <td>
            <strong>${escapeHtml(order.vendorTitle)}</strong>
            <div class="muted">${order.vendorId}</div>
          </td>
          <td class="nowrap">${amountShort(order.amount)}</td>
          <td>${riskBadge(order)}<div class="muted">${order.priorityBand} - ${money.format(order.priorityPct)}%</div></td>
          <td>
            ${reasonGroups[order.reasonGroup]}
            <div class="badge-row">${order.hasChatSignal ? '<span class="badge status-warn">چت حساس</span>' : ""}${order.assignment.isNew ? '<span class="badge status-info">جدید برای کارشناس</span>' : ""}</div>
          </td>
          <td>${expert ? expert.name : "تخصیص نشده"}</td>
          <td>${statusBadge(order.openStatus)}<div class="muted">${order.assignment.reason}</div></td>
          <td>
            <button class="quiet-button" type="button" data-select-order="${order.orderId}">
              <span aria-hidden="true">↗</span>
              مشاهده
            </button>
          </td>
        </tr>
      `;
    })
    .join("");

  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="8" class="muted">با این فیلتر سفارشی پیدا نشد.</td></tr>`;
  }
}

function renderNotifications(order) {
  if (isAdmin()) return "";
  const notifications = state.notifications.filter((item) => item.expertId === currentExpertId() && item.unread);
  if (!notifications.length && !order?.assignment?.isNew) return "";
  return `
    <section class="notice-list">
      ${notifications
        .map(
          (item) => `
            <article class="notice-card">
              <strong>${escapeHtml(item.message)}</strong>
              <small><span class="latin">#${item.orderId}</span> - ${item.at}</small>
            </article>
          `
        )
        .join("")}
    </section>
  `;
}

function renderDetail() {
  const order = getOrder();
  if (!order) {
    $("#orderDetail").innerHTML = `<section class="detail-section">سفارشی برای نمایش وجود ندارد.</section>`;
    return;
  }
  selectedOrderId = order.orderId;
  const expert = getExpert(order.assignment.expertId);
  const stats = expert ? computeExpertStats(expert.id) : null;
  const canAct = isAdmin() || order.assignment.expertId === currentExpertId();
  const chatItems = order.chat.length
    ? order.chat
        .map(
          (item) => `
            <li>
              <strong>${escapeHtml(item.message)}</strong>
              <small>${item.time} - ${item.sender} به ${item.receiver} - ${reasonGroups[item.keywordGroup]} - ${item.messageId}</small>
            </li>
          `
        )
        .join("")
    : `<li><strong>پیام حساسی ثبت نشده است.</strong><small>chat_signal برای این سفارش false است.</small></li>`;

  const actionItems = order.actions.length
    ? order.actions
        .slice()
        .reverse()
        .map(
          (action) => `
            <li>
              <strong>${escapeHtml(action.type)} - ${escapeHtml(action.result)}</strong>
              <small>${escapeHtml(action.note)} - ${action.actorName || "system"} - ${action.at}</small>
            </li>
          `
        )
        .join("")
    : `<li><strong>هنوز اقدامی ثبت نشده است.</strong><small>first_action_at خالی است.</small></li>`;

  $("#orderDetail").innerHTML = `
    ${renderNotifications(order)}
    <div class="detail-header">
      <h3>سفارش <span class="latin">#${order.orderId}</span> | ${escapeHtml(order.vendorTitle)}</h3>
      <p>${toman(order.amount)} - ${order.itemCount} آیتم - ثبت: ${order.createdAt}</p>
      <div class="badge-row">
        ${riskBadge(order)}
        <span class="badge">${order.priorityBand} - ${money.format(order.priorityPct)}%</span>
        ${statusBadge(order.openStatus)}
        <span class="badge">${expert ? expert.name : "بدون کارشناس"}</span>
        ${order.assignment.isNew ? '<span class="badge status-info">سفارش جدید</span>' : ""}
      </div>
    </div>

    <div class="detail-stack">
      ${isAdmin() ? renderAssignmentControl(order) : ""}
      <section class="detail-section">
        <h3>Risk snapshot <span class="badge status-ok">${order.modelVersion}</span></h3>
        <ul class="key-list">
          <li><strong>${reasonGroups[order.reasonGroup]}</strong><small>${escapeHtml(order.evidenceSummary)}</small></li>
          ${order.recommendedAction ? `<li><strong>recommended_action</strong><small>${escapeHtml(order.recommendedAction)}</small></li>` : ""}
          <li><strong>scored_at: ${order.scoredAt}</strong><small>tracking code: ${order.trackingStatus}</small></li>
        </ul>
      </section>

      ${
        order.metabase
          ? `
            <section class="detail-section">
              <h3>Metabase model fields</h3>
              <div class="detail-grid">
                <div class="stat-box"><span class="stat-label">cancel probability</span><strong>${money.format(order.metabase.cancellationProbabilityPct)}%</strong></div>
                <div class="stat-box"><span class="stat-label">risk percentile</span><strong>${money.format(order.metabase.riskPercentile)}%</strong></div>
                <div class="stat-box"><span class="stat-label">business importance</span><strong>${money.format(order.metabase.businessImportancePct)}%</strong></div>
                <div class="stat-box"><span class="stat-label">expected lost commission</span><strong>${toman(order.metabase.expectedLostCommissionToman)}</strong></div>
              </div>
            </section>
          `
          : ""
      }

      <section class="detail-section">
        <h3>کارشناس و عملکرد</h3>
        <div class="detail-grid">
          <div class="stat-box"><span class="stat-label">کارشناس</span><strong>${expert ? expert.name : "تخصیص نشده"}</strong></div>
          <div class="stat-box"><span class="stat-label">سفارش باز کارشناس</span><strong>${stats ? money.format(stats.openCount) : "-"}</strong></div>
          <div class="stat-box"><span class="stat-label">مصرف اعتبار روی این سفارش</span><strong>${toman(order.spend)}</strong></div>
          <div class="stat-box"><span class="stat-label">کمیسیون این سفارش</span><strong>${toman(order.commissionToman)}</strong></div>
        </div>
      </section>

      <section class="detail-section">
        <h3>Evidence</h3>
        <div class="detail-grid">
          <div class="stat-box"><span class="stat-label">Vendor cancel rate</span><strong>${pct(order.vendorHistory.cancelRate)}</strong></div>
          <div class="stat-box"><span class="stat-label">No approve rate</span><strong>${pct(order.vendorHistory.noApproveRate)}</strong></div>
          <div class="stat-box"><span class="stat-label">Delay rate</span><strong>${pct(order.vendorHistory.delayRate)}</strong></div>
          <div class="stat-box"><span class="stat-label">Customer cancel rate</span><strong>${pct(order.customerHistory.cancelRate)}</strong></div>
        </div>
      </section>

      <section class="detail-section">
        <h3>چت حساس</h3>
        <ul class="chat-list">${chatItems}</ul>
      </section>

      ${
        canAct
          ? `
            <section class="detail-section">
              <h3>ثبت اقدام</h3>
              <form id="actionForm" class="form-grid">
                <label class="field">
                  <span>نوع اقدام</span>
                  <select name="type">
                    <option>پیگیری vendor</option>
                    <option>تماس با مشتری</option>
                    <option>ثبت جایگزین</option>
                    <option>انتقال به سرپرست</option>
                    <option>Snooze</option>
                  </select>
                </label>
                <label class="field">
                  <span>وضعیت بعد از اقدام</span>
                  <select name="status">
                    <option value="in_progress">در حال اقدام</option>
                    <option value="waiting_vendor">انتظار vendor</option>
                    <option value="waiting_customer">انتظار مشتری</option>
                    <option value="needs_admin_review">نیازمند بررسی</option>
                    <option value="closed_tracking_code">موفق / ثبت کد رهگیری</option>
                    <option value="closed_cancelled">کنسل شد</option>
                    <option value="closed_refunded">ریفاند شد</option>
                  </select>
                </label>
                <label class="field">
                  <span>کمیسیون ثبت شده</span>
                  <input name="commission" type="number" min="0" step="10000" placeholder="در صورت موفقیت" />
                </label>
                <label class="field span-2">
                  <span>یادداشت</span>
                  <textarea name="note" placeholder="نتیجه پیگیری"></textarea>
                </label>
                <button class="primary-button span-2" type="submit"><span aria-hidden="true">✓</span>ثبت اقدام</button>
              </form>
            </section>

            <section class="detail-section">
              <h3>هزینه و کسری</h3>
              <form id="spendForm" class="form-grid">
                <label class="field">
                  <span>مبلغ</span>
                  <input name="amount" type="number" min="0" step="10000" placeholder="مثلا 350000" />
                </label>
                <label class="field">
                  <span>Reason</span>
                  <select name="reason">
                    <option>هزینه ارسال جایگزین</option>
                    <option>اختلاف قیمت</option>
                    <option>جبران ناموجودی</option>
                    <option>پیگیری فوری vendor</option>
                  </select>
                </label>
                <label class="field span-2">
                  <span>توضیح</span>
                  <textarea name="note" placeholder="توضیح هزینه یا کسری"></textarea>
                </label>
                <button class="primary-button span-2" type="submit"><span aria-hidden="true">＋</span>ثبت هزینه / کسری</button>
              </form>
            </section>
          `
          : ""
      }

      <section class="detail-section">
        <h3>History</h3>
        <ul class="audit-list">${actionItems}</ul>
      </section>

      <section class="detail-section">
        <h3>Outcome</h3>
        <div class="detail-grid">
          <div class="stat-box"><span class="stat-label">وضعیت</span><strong>${statusBadge(order.outcome.status)}</strong></div>
          <div class="stat-box"><span class="stat-label">reason match</span><strong>${order.outcome.reasonMatchStatus}</strong></div>
          <div class="stat-box"><span class="stat-label">refund amount</span><strong>${toman(order.outcome.refundAmount)}</strong></div>
          <div class="stat-box"><span class="stat-label">expert final reason</span><strong>${order.outcome.expertFinalReason || "ثبت نشده"}</strong></div>
        </div>
      </section>
    </div>
  `;
}

function renderAssignmentControl(order) {
  return `
    <section class="detail-section">
      <h3>تخصیص دستی ادمین</h3>
      <form id="singleAssignForm" class="form-grid">
        <input type="hidden" name="orderId" value="${order.orderId}" />
        <label class="field">
          <span>کارشناس</span>
          <select name="expertId" required>
            <option value="">انتخاب کارشناس</option>
            ${state.experts.map((expert) => `<option value="${expert.id}" ${order.assignment.expertId === expert.id ? "selected" : ""}>${expert.name}</option>`).join("")}
          </select>
        </label>
        <label class="check-row">
          <input name="setVendorOwner" type="checkbox" checked />
          این کارشناس owner این vendor شود
        </label>
        <button class="primary-button span-2" type="submit">ثبت / انتقال سفارش</button>
      </form>
    </section>
  `;
}

function renderInboxBoard() {
  const lanes = [
    ["unassigned", "بدون کارشناس"],
    ["P1", "فوری"],
    ["P2", "بالا"],
    ["P3", "پایش"]
  ];

  $("#inboxBoard").innerHTML = lanes
    .map(([laneKey, label]) => {
      const laneOrders =
        laneKey === "unassigned"
          ? visibleOrders().filter((order) => isOpenOrder(order) && !order.assignment.expertId)
          : visibleOrders().filter((order) => order.priorityBand === laneKey);
      return `
        <section class="lane">
          <h3>${label}<span class="badge">${money.format(laneOrders.length)}</span></h3>
          <div class="lane-list">
            ${laneOrders
              .map(
                (order) => `
                  <article class="order-card">
                    <div class="badge-row">${riskBadge(order)}${statusBadge(order.openStatus)}${order.assignment.isNew ? '<span class="badge status-info">جدید</span>' : ""}</div>
                    <strong><span class="latin">#${order.orderId}</span> - ${escapeHtml(order.vendorTitle)}</strong>
                    <span class="muted">${reasonGroups[order.reasonGroup]} - ${toman(order.amount)} - ${getExpertName(order.assignment.expertId)}</span>
                    <button class="quiet-button" type="button" data-select-order="${order.orderId}" data-open-dashboard="true">
                      <span aria-hidden="true">↗</span>
                      باز کردن جزئیات
                    </button>
                  </article>
                `
              )
              .join("") || `<p class="muted">سفارشی در این ستون نیست.</p>`}
          </div>
        </section>
      `;
    })
    .join("");
}

function renderVendorWorkspace() {
  const selected = getOrder();
  if (!selected) {
    $("#vendorWorkspace").innerHTML = `
      <div class="vendor-summary">
        <section class="report-panel">
          <h3>Vendor Workspace</h3>
          <p class="muted">هنوز سفارشی برای نمایش وجود ندارد. خروجی CSV یا JSON کوئری Metabase را از پنل ادمین وارد کن.</p>
        </section>
      </div>
    `;
    return;
  }
  const vendorOrders = visibleOrders().filter((order) => order.vendorId === selected.vendorId);
  const ownerId = state.vendorOwners[selected.vendorId] || "";
  const owner = getExpert(ownerId);
  const totalAmount = vendorOrders.reduce((sum, order) => sum + order.amount, 0);
  const chatSignals = vendorOrders.filter((order) => order.hasChatSignal).length;

  $("#vendorWorkspace").innerHTML = `
    <div class="vendor-summary">
      <div class="summary-strip">
        <div class="summary-item"><span class="stat-label">Vendor</span><strong>${escapeHtml(selected.vendorTitle)}</strong><small class="muted">${selected.vendorId}</small></div>
        <div class="summary-item"><span class="stat-label">owner فعلی vendor</span><strong>${owner ? owner.name : "ثبت نشده"}</strong></div>
        <div class="summary-item"><span class="stat-label">سفارش های این vendor</span><strong>${money.format(vendorOrders.length)}</strong></div>
        <div class="summary-item"><span class="stat-label">GMV</span><strong>${toman(totalAmount)}</strong></div>
      </div>
      <div class="split-grid">
        <section class="report-panel">
          <h3>قانون تخصیص</h3>
          <ul class="key-list">
            <li><strong>بدون owner</strong><small>سفارش جدید تخصیص نمی خورد و در صف بدون کارشناس می ماند.</small></li>
            <li><strong>با owner</strong><small>سفارش های باز بعدی همین vendor به owner فعلی منتقل می شوند.</small></li>
            <li><strong>تغییر owner</strong><small>فقط از پنل ادمین و با audit انجام می شود.</small></li>
          </ul>
        </section>
        <section class="report-panel">
          <h3>ریسک vendor</h3>
          <div class="bar-chart">
            <div class="bar-row"><span>cancel rate</span><div class="bar-track"><div class="bar-fill danger" style="width:${Math.round(selected.vendorHistory.cancelRate * 100)}%"></div></div><strong>${pct(selected.vendorHistory.cancelRate)}</strong></div>
            <div class="bar-row"><span>no approve</span><div class="bar-track"><div class="bar-fill warn" style="width:${Math.round(selected.vendorHistory.noApproveRate * 100)}%"></div></div><strong>${pct(selected.vendorHistory.noApproveRate)}</strong></div>
            <div class="bar-row"><span>delay</span><div class="bar-track"><div class="bar-fill" style="width:${Math.round(selected.vendorHistory.delayRate * 100)}%"></div></div><strong>${pct(selected.vendorHistory.delayRate)}</strong></div>
          </div>
        </section>
      </div>
      <div class="table-shell">
        <table>
          <thead><tr><th>Order</th><th>Risk</th><th>Reason</th><th>مبلغ</th><th>کارشناس</th><th>وضعیت</th></tr></thead>
          <tbody>
            ${vendorOrders
              .map(
                (order) => `
                  <tr class="${order.orderId === selected.orderId ? "is-selected" : ""}">
                    <td><button class="order-link" type="button" data-select-order="${order.orderId}"><span class="latin">#${order.orderId}</span></button></td>
                    <td>${riskBadge(order)}</td>
                    <td>${reasonGroups[order.reasonGroup]}</td>
                    <td>${toman(order.amount)}</td>
                    <td>${getExpertName(order.assignment.expertId)}</td>
                    <td>${statusBadge(order.openStatus)}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderDeficitWorkspace() {
  const rows = isAdmin() ? state.deficits : state.deficits.filter((deficit) => deficit.expertId === currentExpertId());
  $("#deficitWorkspace").innerHTML = `
    <div class="deficit-grid">
      <section class="report-panel">
        <h3>اعتبار کارشناسان</h3>
        <div class="table-shell">
          <table>
            <thead><tr><th>کارشناس</th><th>مانده</th><th>مصرف</th><th>کسری pending</th><th>سفارش باز</th><th>کمیسیون</th></tr></thead>
            <tbody>
              ${(isAdmin() ? state.experts : state.experts.filter((expert) => expert.id === currentExpertId()))
                .map((expert) => {
                  const stats = computeExpertStats(expert.id);
                  return `<tr><td>${expert.name}</td><td>${toman(stats.balance)}</td><td>${toman(stats.creditSpent)}</td><td>${toman(stats.pendingDeficit)}</td><td>${money.format(stats.openCount)}</td><td>${toman(stats.commission)}</td></tr>`;
                })
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
      <section class="report-panel">
        <h3>درخواست های کسری</h3>
        <div class="table-shell">
          <table>
            <thead><tr><th>شناسه</th><th>Order</th><th>کارشناس</th><th>مبلغ</th><th>Reason</th><th>وضعیت</th><th>اقدام</th></tr></thead>
            <tbody>
              ${rows
                .map(
                  (deficit) => `
                    <tr>
                      <td>${deficit.id}</td>
                      <td><span class="latin">#${deficit.orderId}</span></td>
                      <td>${getExpertName(deficit.expertId)}</td>
                      <td>${toman(deficit.amount)}</td>
                      <td>${escapeHtml(deficit.reason)}</td>
                      <td>${statusBadge(deficit.status)}</td>
                      <td>
                        ${
                          isAdmin() && deficit.status === "pending"
                            ? `<div class="quick-actions"><button class="quiet-button" type="button" data-approve-deficit="${deficit.id}">تایید</button><button class="quiet-button" type="button" data-reject-deficit="${deficit.id}">رد</button></div>`
                            : "-"
                        }
                      </td>
                    </tr>
                  `
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `;
}

function renderDataSourcePanel() {
  const meta = state.dataSourceMeta || {};
  const statusTone = state.dataSource === "metabase_import" ? "status-ok" : state.dataSource === "sample_local" ? "status-warn" : "status-info";
  const statusText =
    state.dataSource === "metabase_import"
      ? "خروجی واقعی وارد شده"
      : state.dataSource === "sample_local"
        ? "حالت نمونه"
        : "منتظر خروجی";

  return `
    <section class="data-banner">
      <div class="badge-row">
        <strong>وضعیت داده ها</strong>
        <span class="badge ${statusTone}">${statusText}</span>
      </div>
      <span>${escapeHtml(meta.note || dataSourceEyebrow())}</span>
      <div class="data-source-grid">
        <div><small>Metabase question</small><strong>${METABASE_QUERY.id}</strong></div>
        <div><small>مدل</small><strong>${escapeHtml(meta.queryTitle || METABASE_QUERY.title)}</strong></div>
        <div><small>ردیف وارد شده</small><strong>${money.format(meta.rowCount || state.orders.length || 0)}</strong></div>
        <div><small>فایل</small><strong>${escapeHtml(meta.fileName || "-")}</strong></div>
      </div>
    </section>
  `;
}

function renderMetabaseImportPanel() {
  return `
    <section class="report-panel">
      <h3>اتصال بک‌اند محصول</h3>
      <div class="summary-strip">
        <div class="summary-item"><span class="stat-label">Endpoint</span><strong>/api/orders</strong></div>
        <div class="summary-item"><span class="stat-label">Query file</span><strong>backend/high-risk-priority.sql</strong></div>
        <div class="summary-item"><span class="stat-label">Mode</span><strong>${state.dataSource === "backend_query" ? "Backend live" : "Ready"}</strong></div>
        <div class="summary-item"><span class="stat-label">آخرین ردیف</span><strong>${money.format(state.dataSourceMeta?.rowCount || state.orders.length || 0)}</strong></div>
      </div>
      <div class="quick-actions">
        <button class="primary-button" type="button" id="backendRefreshBtn">رفرش سفارش ها از بک‌اند</button>
        <a class="quiet-button" href="${BACKEND_BASE || ""}/api/health" target="_blank" rel="noreferrer">وضعیت بک‌اند</a>
      </div>
    </section>

    <section class="report-panel">
      <h3>ورود خروجی Metabase</h3>
      <form id="metabaseImportForm" class="form-grid">
        <label class="field span-2">
          <span>فایل CSV یا JSON خروجی question ${METABASE_QUERY.id}</span>
          <input name="metabaseFile" type="file" accept=".csv,.json,text/csv,application/json" required />
        </label>
        <label class="check-row span-2">
          <input name="applyVendorOwner" type="checkbox" checked />
          بعد از import، فقط سفارش vendorهایی که owner دارند به همان کارشناس اختصاص داده شود
        </label>
        <button class="primary-button" type="submit">Import داده واقعی</button>
        <button class="quiet-button" type="button" id="clearOperationalDataBtn">پاک کردن سفارش ها</button>
      </form>
      <ul class="key-list metabase-columns">
        <li>
          <strong>ستون های اصلی مورد استفاده</strong>
          <small>${METABASE_QUERY.expectedColumns.map(escapeHtml).join("، ")}</small>
        </li>
        <li>
          <strong>منطق نمایش سفارش ها</strong>
          <small>اولویت از خود ستون های priority_pct / priority_band می آید؛ تخصیص خودکار عمومی نداریم و فقط قانون vendor owner اعمال می شود.</small>
        </li>
      </ul>
    </section>
  `;
}

function renderAdminWorkspace() {
  const selectedExpert = getExpert(selectedAdminExpertId) || state.experts[0];
  selectedAdminExpertId = selectedExpert?.id || "";
  const selectedStats = selectedExpert ? computeExpertStats(selectedExpert.id) : null;
  const unassignedOpenOrders = state.orders.filter((order) => isOpenOrder(order) && !order.assignment.expertId);

  $("#adminWorkspace").innerHTML = `
    <div class="admin-grid">
      ${renderDataSourcePanel()}
      ${renderMetabaseImportPanel()}

      <div class="split-grid">
        <section class="report-panel">
          <h3>ثبت کارشناس</h3>
          <form id="expertForm" class="form-grid">
            <label class="field"><span>نام کارشناس</span><input name="name" required placeholder="مثلا رضا احمدی" /></label>
            <label class="field"><span>نام کاربری</span><input name="username" required autocomplete="off" /></label>
            <label class="field"><span>رمز عبور</span><input name="password" required autocomplete="new-password" /></label>
            <label class="field"><span>ظرفیت سفارش باز</span><input name="capacity" type="number" min="1" value="10" required /></label>
            <button class="primary-button span-2" type="submit">ثبت کارشناس و ساخت پنل</button>
          </form>
        </section>

        <section class="report-panel">
          <h3>تخصیص دستی سفارش</h3>
          <form id="manualAssignForm" class="form-grid">
            <label class="field">
              <span>سفارش بدون کارشناس</span>
              <select name="orderId" required>
                <option value="">انتخاب سفارش</option>
                ${unassignedOpenOrders.map((order) => `<option value="${order.orderId}">#${order.orderId} - ${order.vendorTitle}</option>`).join("")}
              </select>
            </label>
            <label class="field">
              <span>کارشناس</span>
              <select name="expertId" required>
                <option value="">انتخاب کارشناس</option>
                ${state.experts.map((expert) => `<option value="${expert.id}">${expert.name}</option>`).join("")}
              </select>
            </label>
            <label class="check-row span-2"><input name="setVendorOwner" type="checkbox" checked />این کارشناس owner این vendor شود</label>
            <button class="primary-button span-2" type="submit">تخصیص سفارش</button>
          </form>
        </section>
      </div>

      <section class="report-panel">
        <h3>عملکرد کارشناسان</h3>
        <div class="table-shell">
          <table>
            <thead><tr><th>کارشناس</th><th>username</th><th>سفارش باز</th><th>موفق</th><th>کنسل</th><th>مصرف اعتبار</th><th>کمیسیون</th><th>جزئیات</th></tr></thead>
            <tbody>
              ${state.experts
                .map((expert) => {
                  const stats = computeExpertStats(expert.id);
                  return `
                    <tr class="${expert.id === selectedAdminExpertId ? "is-selected" : ""}">
                      <td>${expert.name}</td>
                      <td>${expert.username}</td>
                      <td>${money.format(stats.openCount)}</td>
                      <td>${money.format(stats.successCount)}</td>
                      <td>${money.format(stats.canceledCount)}</td>
                      <td>${toman(stats.creditSpent)}</td>
                      <td>${toman(stats.commission)}</td>
                      <td><button class="quiet-button" type="button" data-admin-expert="${expert.id}">مشاهده</button></td>
                    </tr>
                  `;
                })
                .join("")}
            </tbody>
          </table>
        </div>
      </section>

      ${
        selectedExpert
          ? `
            <section class="report-panel">
              <h3>ویرایش کارشناس انتخاب شده</h3>
              <form id="expertEditForm" class="form-grid">
                <input type="hidden" name="expertId" value="${selectedExpert.id}" />
                <label class="field"><span>نام کارشناس</span><input name="name" value="${escapeHtml(selectedExpert.name)}" required /></label>
                <label class="field"><span>نام کاربری</span><input name="username" value="${escapeHtml(selectedExpert.username)}" required autocomplete="off" /></label>
                <label class="field"><span>رمز عبور جدید</span><input name="password" autocomplete="new-password" placeholder="خالی بماند یعنی تغییر نکند" /></label>
                <label class="field"><span>ظرفیت سفارش باز</span><input name="capacity" type="number" min="1" value="${selectedExpert.capacity || 10}" required /></label>
                <button class="primary-button span-2" type="submit">ذخیره تغییرات کارشناس</button>
              </form>
            </section>

            <section class="report-panel">
              <h3>جزئیات عملکرد ${selectedExpert.name}</h3>
              <div class="summary-strip">
                <div class="summary-item"><span class="stat-label">سفارش باز</span><strong>${money.format(selectedStats.openCount)}</strong></div>
                <div class="summary-item"><span class="stat-label">موفق</span><strong>${money.format(selectedStats.successCount)}</strong></div>
                <div class="summary-item"><span class="stat-label">کنسل</span><strong>${money.format(selectedStats.canceledCount)}</strong></div>
                <div class="summary-item"><span class="stat-label">کمیسیون</span><strong>${toman(selectedStats.commission)}</strong></div>
              </div>
              <div class="table-shell">
                <table>
                  <thead><tr><th>Order</th><th>Vendor</th><th>وضعیت</th><th>مصرف</th><th>کمیسیون</th><th>آخرین اقدام</th></tr></thead>
                  <tbody>
                    ${selectedStats.orders
                      .map((order) => {
                        const latest = order.actions.at(-1);
                        return `
                          <tr>
                            <td><button class="order-link" type="button" data-select-order="${order.orderId}" data-open-dashboard="true"><span class="latin">#${order.orderId}</span></button></td>
                            <td>${order.vendorTitle}</td>
                            <td>${statusBadge(order.openStatus)}</td>
                            <td>${toman(order.spend)}</td>
                            <td>${toman(order.commissionToman)}</td>
                            <td>${latest ? `${escapeHtml(latest.type)} - ${escapeHtml(latest.note)}` : "اقدامی ثبت نشده"}</td>
                          </tr>
                        `;
                      })
                      .join("")}
                  </tbody>
                </table>
              </div>
            </section>
          `
          : ""
      }

      <div class="split-grid">
        <section class="report-panel">
          <h3>کلمات حساس</h3>
          <div class="keyword-grid">
            ${state.keywordRules
              .map(
                (rule) => `
                  <div class="summary-item">
                    <div class="badge-row">
                      <strong>${escapeHtml(rule.keyword)}</strong>
                      <button class="toggle ${rule.active ? "is-on" : ""}" type="button" aria-label="تغییر وضعیت keyword" data-toggle-keyword="${rule.id}"></button>
                    </div>
                    <small class="muted">${reasonGroups[rule.group]} - severity: ${rule.severity} - v${rule.version}</small>
                  </div>
                `
              )
              .join("")}
          </div>
        </section>
        <section class="report-panel">
          <h3>audit trail</h3>
          <ul class="audit-list">
            ${state.auditLogs
              .slice()
              .reverse()
              .map((log) => `<li><strong>${escapeHtml(log.action)}</strong><small>${escapeHtml(log.actor)} - ${escapeHtml(log.entity)} - ${log.at}</small></li>`)
              .join("")}
          </ul>
        </section>
      </div>
    </div>
  `;
}

function render() {
  renderShell();
  if (!currentUser) return;
  const visible = visibleOrders();
  if (!visible.some((order) => order.orderId === selectedOrderId)) {
    selectedOrderId = visible[0]?.orderId || state.orders[0]?.orderId;
  }
  renderMetrics();
  renderOrdersTable();
  renderDetail();
  renderInboxBoard();
  renderVendorWorkspace();
  renderDeficitWorkspace();
  if (isAdmin()) renderAdminWorkspace();
}

function setView(view) {
  if (view === "admin" && !isAdmin()) view = "dashboard";
  activeView = view;
  $$("[data-panel]").forEach((panel) => panel.classList.toggle("is-hidden", panel.dataset.panel !== view));
  $$(".nav-item").forEach((button) => button.classList.toggle("is-active", button.dataset.view === view));
}

function assignOrder(orderId, expertId, setVendorOwner, reason) {
  const order = state.orders.find((item) => item.orderId === orderId);
  const expert = getExpert(expertId);
  if (!order || !expert) return false;

  order.assignment.expertId = expert.id;
  order.assignment.status = "new";
  order.assignment.assignedAt = nowText();
  order.assignment.reason = reason;
  order.assignment.isNew = true;
  order.openStatus = order.openStatus === "unassigned" ? "new" : order.openStatus;
  if (setVendorOwner) state.vendorOwners[order.vendorId] = expert.id;

  addNotification(expert.id, order.orderId, `سفارش جدید ${order.orderId} به شما اختصاص داده شد.`);
  addAudit("order.assigned", `${order.orderId} -> ${expert.id}`);
  return true;
}

function applyVendorOwnerAssignments() {
  const candidates = state.orders.filter((order) => isOpenOrder(order) && !order.assignment.expertId);
  let assigned = 0;
  let skipped = 0;

  candidates.forEach((order) => {
    const ownerId = orderVendorIds(order).map((vendorId) => state.vendorOwners[vendorId]).find(Boolean);
    if (!ownerId) {
      skipped += 1;
      addAudit("vendor_owner.skipped_no_owner", order.orderId, "system");
      return;
    }
    if (assignOrder(order.orderId, ownerId, false, "vendor owner")) assigned += 1;
  });

  return { assigned, skipped };
}

function applyVendorOwnerRule() {
  if (!isAdmin()) return;
  const { assigned, skipped } = applyVendorOwnerAssignments();
  saveState();
  render();
  setView(activeView);
  showToast(`${money.format(assigned)} سفارش با vendor owner تخصیص خورد؛ ${money.format(skipped)} سفارش بدون owner ماند.`);
}

function handleActionSubmit(event) {
  event.preventDefault();
  const order = getOrder();
  const form = event.target;
  const data = new FormData(form);
  const type = String(data.get("type"));
  const status = String(data.get("status"));
  const note = String(data.get("note") || "").trim() || "بدون یادداشت";
  const commissionInput = Number(data.get("commission"));
  const actorExpert = getExpert(currentExpertId()) || getExpert(order.assignment.expertId);

  order.openStatus = status;
  order.assignment.status = status;
  order.assignment.isNew = false;
  order.actions.push({
    actorId: actorExpert?.id || "admin",
    actorName: actorExpert?.name || currentUser.name,
    type,
    result: statusBadge(status).replace(/<[^>]*>/g, ""),
    note,
    at: nowText()
  });

  if (status === "closed_tracking_code") {
    order.trackingStatus = "ثبت شده";
    order.outcome.status = "closed_tracking_code";
    order.outcome.trackingCode = `TR-${order.orderId}`;
    order.outcome.expertFinalReason = note;
    order.outcome.reasonMatchStatus = "matched";
    order.commissionToman = commissionInput || order.commissionToman || Math.round(order.amount * 0.05);
  }

  if (status === "closed_cancelled") {
    order.outcome.status = "closed_cancelled";
    order.outcome.cancelledAt = nowText();
    order.outcome.expertFinalReason = note;
    order.outcome.reasonMatchStatus = "matched";
  }

  if (status === "closed_refunded") {
    order.outcome.status = "closed_refunded";
    order.outcome.refundAt = nowText();
    order.outcome.refundAmount = order.amount;
    order.outcome.expertFinalReason = note;
    order.outcome.reasonMatchStatus = "manual_review";
  }

  state.notifications
    .filter((item) => item.orderId === order.orderId && item.expertId === order.assignment.expertId)
    .forEach((item) => {
      item.unread = false;
    });

  addAudit("order_action.created", order.orderId);
  saveState();
  form.reset();
  render();
  setView(activeView);
  showToast(`اقدام برای سفارش #${order.orderId} ثبت شد.`);
}

function handleSpendSubmit(event) {
  event.preventDefault();
  const order = getOrder();
  const form = event.target;
  const data = new FormData(form);
  const amount = Number(data.get("amount"));
  const reason = String(data.get("reason"));
  const note = String(data.get("note") || "").trim() || "بدون توضیح";
  const expert = getExpert(order.assignment.expertId);

  if (!expert) {
    showToast("این سفارش هنوز کارشناس ندارد. ادمین باید آن را تخصیص بدهد.");
    return;
  }
  if (!amount || amount <= 0) {
    showToast("مبلغ معتبر وارد کنید.");
    return;
  }

  const stats = computeExpertStats(expert.id);
  if (amount > stats.balance) {
    const deficit = {
      id: `D-${Date.now().toString().slice(-5)}`,
      orderId: order.orderId,
      expertId: expert.id,
      vendorId: order.vendorId,
      amount,
      reason,
      note,
      status: "pending",
      createdAt: nowText()
    };
    state.deficits.push(deficit);
    order.deficitPending += amount;
    order.actions.push({ actorId: expert.id, actorName: expert.name, type: "ثبت کسری", result: "در انتظار تایید", note, at: nowText() });
    addAudit("deficit_request.created", deficit.id);
    showToast("موجودی کافی نبود؛ درخواست کسری در انتظار تایید ثبت شد.");
  } else {
    order.spend += amount;
    order.actions.push({ actorId: expert.id, actorName: expert.name, type: "ثبت هزینه", result: "posted", note: `${reason} - ${note}`, at: nowText() });
    addAudit("credit_transaction.posted", order.orderId);
    showToast("هزینه ثبت شد و مصرف اعتبار بروزرسانی شد.");
  }

  saveState();
  form.reset();
  render();
  setView(activeView);
}

function approveDeficit(id) {
  const deficit = state.deficits.find((item) => item.id === id);
  if (!deficit || deficit.status !== "pending") return;
  const order = state.orders.find((item) => item.orderId === deficit.orderId);
  deficit.status = "approved";
  if (order) {
    order.deficitPending = Math.max(0, order.deficitPending - deficit.amount);
    order.spend += deficit.amount;
    order.actions.push({ actorId: "admin", actorName: currentUser.name, type: "تایید کسری", result: "approved", note: deficit.reason, at: nowText() });
  }
  addAudit("deficit_request.approved", id);
  saveState();
  render();
  setView(activeView);
  showToast(`کسری ${id} تایید شد.`);
}

function rejectDeficit(id) {
  const deficit = state.deficits.find((item) => item.id === id);
  if (!deficit || deficit.status !== "pending") return;
  const order = state.orders.find((item) => item.orderId === deficit.orderId);
  deficit.status = "rejected";
  if (order) order.deficitPending = Math.max(0, order.deficitPending - deficit.amount);
  addAudit("deficit_request.rejected", id);
  saveState();
  render();
  setView(activeView);
  showToast(`کسری ${id} رد شد.`);
}

function toggleKeyword(id) {
  const rule = state.keywordRules.find((item) => item.id === id);
  if (!rule) return;
  rule.active = !rule.active;
  rule.version += 1;
  addAudit("keyword_rule.updated", id);
  saveState();
  render();
  setView(activeView);
  showToast(`keyword «${rule.keyword}» ${rule.active ? "فعال" : "غیرفعال"} شد.`);
}

function handleExpertForm(event) {
  event.preventDefault();
  const data = new FormData(event.target);
  const username = String(data.get("username") || "").trim();
  const name = String(data.get("name") || "").trim();
  const password = String(data.get("password") || "").trim();
  const capacity = Number(data.get("capacity")) || 10;

  if (state.users.some((user) => user.username === username)) {
    showToast("این نام کاربری قبلا ثبت شده است.");
    return;
  }

  const nextNumber = 100 + state.experts.length + 1;
  const expertId = `E-${nextNumber}`;
  const userId = `U-${nextNumber}`;
  state.experts.push({
    id: expertId,
    name,
    username,
    status: "active",
    shift: "online",
    capacity,
    openingAmount: 10000000,
    topUps: 0,
    skillTags: []
  });
  state.users.push({ id: userId, username, password, role: "expert", expertId, name });
  selectedAdminExpertId = expertId;
  addAudit("expert.created", expertId);
  saveState();
  event.target.reset();
  render();
  setView("admin");
  showToast(`کارشناس ${name} ثبت شد و پنلش ساخته شد.`);
}

function handleExpertEdit(event) {
  event.preventDefault();
  const data = new FormData(event.target);
  const expertId = String(data.get("expertId") || "");
  const expert = getExpert(expertId);
  if (!expert) return;

  const name = String(data.get("name") || "").trim();
  const username = String(data.get("username") || "").trim();
  const password = String(data.get("password") || "").trim();
  const capacity = Number(data.get("capacity")) || expert.capacity || 10;
  const user = state.users.find((item) => item.expertId === expert.id);

  if (!name || !username) {
    showToast("نام و username کارشناس را کامل وارد کن.");
    return;
  }

  const usernameTaken = state.users.some((item) => item.username === username && item.id !== user?.id);
  if (usernameTaken) {
    showToast("این username برای کاربر دیگری ثبت شده است.");
    return;
  }

  expert.name = name;
  expert.username = username;
  expert.capacity = capacity;

  if (user) {
    user.name = name;
    user.username = username;
    if (password) user.password = password;
  }

  if (currentUser?.id === user?.id) currentUser = user;
  addAudit("expert.updated", expert.id);
  saveState();
  render();
  setView("admin");
  showToast(`اطلاعات ${name} بروزرسانی شد.`);
}

function handleManualAssign(event) {
  event.preventDefault();
  const data = new FormData(event.target);
  const orderId = String(data.get("orderId"));
  const expertId = String(data.get("expertId"));
  const setVendorOwner = data.get("setVendorOwner") === "on";
  if (!assignOrder(orderId, expertId, setVendorOwner, "manual admin assignment")) {
    showToast("تخصیص انجام نشد.");
    return;
  }
  saveState();
  render();
  setView("admin");
  showToast("سفارش به کارشناس تخصیص داده شد و به عنوان سفارش جدید علامت خورد.");
}

function handleSingleAssign(event) {
  event.preventDefault();
  const data = new FormData(event.target);
  const orderId = String(data.get("orderId"));
  const expertId = String(data.get("expertId"));
  const setVendorOwner = data.get("setVendorOwner") === "on";
  if (!assignOrder(orderId, expertId, setVendorOwner, "manual admin assignment")) return;
  saveState();
  render();
  setView(activeView);
  showToast("تخصیص سفارش بروزرسانی شد.");
}

function setPreset(preset) {
  activePreset = preset;
  $$(".segment").forEach((button) => button.classList.toggle("is-active", button.dataset.filterPreset === preset));
  $("#searchInput").value = "";
  $("#riskFilter").value = "all";
  $("#reasonFilter").value = "all";
  $("#chatOnlyFilter").checked = false;
  $("#deficitOnlyFilter").checked = false;
  if (preset === "chat") $("#chatOnlyFilter").checked = true;
  renderOrdersTable();
}

function handleLogin(event) {
  event.preventDefault();
  const data = new FormData(event.target);
  const username = String(data.get("username") || "").trim();
  const password = String(data.get("password") || "").trim();
  const user = state.users.find((item) => item.username === username && item.password === password);
  if (!user) {
    $("#loginError").textContent = "نام کاربری یا رمز عبور درست نیست. برای تست از admin / admin123 استفاده کن یا داده نمونه را بازنشانی کن.";
    return;
  }
  $("#loginError").textContent = "";
  saveSession(user);
  activeView = "dashboard";
  selectedOrderId = visibleOrders()[0]?.orderId || state.orders[0]?.orderId;
  render();
  setView("dashboard");
  syncBackendOrders({ silent: true });
}

function wireEvents() {
  ["searchInput", "riskFilter", "reasonFilter", "chatOnlyFilter", "deficitOnlyFilter"].forEach((id) => {
    const element = $(`#${id}`);
    element?.addEventListener("input", () => renderOrdersTable());
    element?.addEventListener("change", () => renderOrdersTable());
  });

  $("#loginForm").addEventListener("submit", handleLogin);
  $("#demoAdminLoginBtn").addEventListener("click", () => {
    let user = state.users.find((item) => item.username === "admin" && item.role === "admin");
    if (!user) {
      ensureDefaultAccess();
      user = state.users.find((item) => item.username === "admin" && item.role === "admin");
    }
    saveSession(user);
    selectedOrderId = visibleOrders()[0]?.orderId || state.orders[0]?.orderId;
    render();
    setView("dashboard");
    syncBackendOrders({ silent: true });
  });
  $("#resetDemoDataBtn").addEventListener("click", resetDemoData);
  $("#logoutBtn").addEventListener("click", () => {
    clearSession();
    render();
  });
  $("#vendorOwnerBtn").addEventListener("click", applyVendorOwnerRule);

  document.addEventListener("click", (event) => {
    const selectButton = event.target.closest("[data-select-order]");
    if (selectButton) {
      selectedOrderId = selectButton.dataset.selectOrder;
      render();
      setView(selectButton.dataset.openDashboard ? "dashboard" : activeView);
      return;
    }

    const navButton = event.target.closest("[data-view]");
    if (navButton) {
      setView(navButton.dataset.view);
      return;
    }

    const presetButton = event.target.closest("[data-filter-preset]");
    if (presetButton) {
      setPreset(presetButton.dataset.filterPreset);
      return;
    }

    const expertButton = event.target.closest("[data-admin-expert]");
    if (expertButton) {
      selectedAdminExpertId = expertButton.dataset.adminExpert;
      render();
      setView("admin");
      return;
    }

    const approveButton = event.target.closest("[data-approve-deficit]");
    if (approveButton) {
      approveDeficit(approveButton.dataset.approveDeficit);
      return;
    }

    const rejectButton = event.target.closest("[data-reject-deficit]");
    if (rejectButton) {
      rejectDeficit(rejectButton.dataset.rejectDeficit);
      return;
    }

    const keywordButton = event.target.closest("[data-toggle-keyword]");
    if (keywordButton) toggleKeyword(keywordButton.dataset.toggleKeyword);

    if (event.target.closest("#clearOperationalDataBtn")) {
      clearOperationalData();
    }

    if (event.target.closest("#backendRefreshBtn")) {
      syncBackendOrders();
    }
  });

  document.addEventListener("submit", (event) => {
    if (event.target.id === "actionForm") handleActionSubmit(event);
    if (event.target.id === "spendForm") handleSpendSubmit(event);
    if (event.target.id === "expertForm") handleExpertForm(event);
    if (event.target.id === "expertEditForm") handleExpertEdit(event);
    if (event.target.id === "manualAssignForm") handleManualAssign(event);
    if (event.target.id === "singleAssignForm") handleSingleAssign(event);
    if (event.target.id === "metabaseImportForm") handleMetabaseImport(event);
  });
}

renderReasonOptions();
wireEvents();
render();
setView(currentUser ? "dashboard" : activeView);
if (currentUser && !backendSyncAttempted) {
  backendSyncAttempted = true;
  syncBackendOrders({ silent: true });
}
