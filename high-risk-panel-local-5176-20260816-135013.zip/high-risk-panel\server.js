const http = require("http");
const fs = require("fs");
const path = require("path");

const rootDir = __dirname;
const backendDir = path.join(rootDir, "backend");

loadEnv(path.join(rootDir, ".env"));

const config = {
  port: Number(process.env.PORT || 5173),
  provider: String(process.env.HIGH_RISK_DATA_PROVIDER || "metabase").toLowerCase(),
  sqlFile: path.resolve(rootDir, process.env.HIGH_RISK_SQL_FILE || "backend/high-risk-priority.sql"),
  fileExport: process.env.HIGH_RISK_FILE_EXPORT ? path.resolve(rootDir, process.env.HIGH_RISK_FILE_EXPORT) : "",
  maxRows: Number(process.env.HIGH_RISK_MAX_ROWS || 1000),
  dateFilter: String(process.env.HIGH_RISK_DATE_FILTER || "today").toLowerCase(),
  timezone: process.env.HIGH_RISK_TIMEZONE || "Asia/Tehran",
  metabaseUrl: trimSlash(process.env.METABASE_URL || "https://metabase.basalam.dev"),
  metabaseCardId: String(process.env.METABASE_CARD_ID || "105017"),
  metabaseSessionToken: process.env.METABASE_SESSION_TOKEN || "",
  metabaseUsername: process.env.METABASE_USERNAME || "",
  metabasePassword: process.env.METABASE_PASSWORD || "",
  clickhouseUrl: process.env.CLICKHOUSE_URL || "",
  clickhouseUser: process.env.CLICKHOUSE_USER || "",
  clickhousePassword: process.env.CLICKHOUSE_PASSWORD || "",
  clickhouseDatabase: process.env.CLICKHOUSE_DATABASE || ""
};

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon"
};

const server = http.createServer(async (req, res) => {
  try {
    setCommonHeaders(res);
    const url = new URL(req.url, `http://${req.headers.host || "127.0.0.1"}`);

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }

    if (url.pathname === "/api/health") {
      sendJson(res, 200, {
        ok: true,
        provider: config.provider,
        queryFile: path.relative(rootDir, config.sqlFile),
        queryFileExists: fs.existsSync(config.sqlFile),
        metabaseCardId: config.metabaseCardId,
        hasMetabaseSession: Boolean(config.metabaseSessionToken),
        hasMetabaseLogin: Boolean(config.metabaseUsername && config.metabasePassword),
        hasClickHouseUrl: Boolean(config.clickhouseUrl),
        dateFilter: config.dateFilter,
        today: dateKeyInTimezone(new Date(), config.timezone),
        timezone: config.timezone,
        fileExport: config.fileExport ? path.relative(rootDir, config.fileExport) : ""
      });
      return;
    }

    if (url.pathname === "/api/orders") {
      const limit = clamp(Number(url.searchParams.get("limit") || config.maxRows), 1, 10000);
      const dateFilter = String(url.searchParams.get("date") || config.dateFilter).toLowerCase();
      const rows = await fetchOrders(limit, dateFilter);
      sendJson(res, 200, {
        ok: true,
        provider: config.provider,
        queryId: Number(config.metabaseCardId),
        queryTitle: "live_priority_v4_1_value_aware_2026_08_01",
        dateFilter,
        today: dateKeyInTimezone(new Date(), config.timezone),
        timezone: config.timezone,
        rowCount: rows.length,
        refreshedAt: new Date().toISOString(),
        rows
      });
      return;
    }

    await serveStatic(url.pathname, res);
  } catch (error) {
    const status = Number(error.statusCode || error.status || 500);
    sendJson(res, status, {
      ok: false,
      error: error.message || "Backend error",
      provider: config.provider
    });
  }
});

server.listen(config.port, "127.0.0.1", () => {
  console.log(`High Risk panel backend is running at http://127.0.0.1:${config.port}/`);
  console.log(`Provider: ${config.provider}`);
});

async function fetchOrders(limit, dateFilter) {
  const rows = await fetchProviderRows(Math.max(limit, config.maxRows));
  return filterRowsByDate(rows, dateFilter).slice(0, limit);
}

async function fetchProviderRows(limit) {
  if (config.provider === "clickhouse") return queryClickHouse(limit);
  if (config.provider === "file") return readFileExport(limit);
  return queryMetabaseCard(limit);
}

async function queryMetabaseCard(limit) {
  const token = await getMetabaseSession();
  const url = `${config.metabaseUrl}/api/card/${encodeURIComponent(config.metabaseCardId)}/query/json`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-metabase-session": token
    },
    body: JSON.stringify({ parameters: [] })
  });

  if (!response.ok) {
    const body = await safeText(response);
    throw httpError(response.status, `Metabase query failed: ${response.status} ${body.slice(0, 220)}`);
  }

  const rows = await response.json();
  if (!Array.isArray(rows)) throw httpError(502, "Metabase response is not a row array.");
  return rows.slice(0, limit);
}

async function getMetabaseSession() {
  if (config.metabaseSessionToken) return config.metabaseSessionToken;
  if (!config.metabaseUsername || !config.metabasePassword) {
    throw httpError(503, "Metabase credential is missing. Set METABASE_SESSION_TOKEN or METABASE_USERNAME / METABASE_PASSWORD in .env.");
  }

  const response = await fetch(`${config.metabaseUrl}/api/session`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ username: config.metabaseUsername, password: config.metabasePassword })
  });

  if (!response.ok) {
    const body = await safeText(response);
    throw httpError(response.status, `Metabase login failed: ${response.status} ${body.slice(0, 220)}`);
  }

  const payload = await response.json();
  if (!payload.id) throw httpError(502, "Metabase login did not return a session id.");
  config.metabaseSessionToken = payload.id;
  return payload.id;
}

async function queryClickHouse(limit) {
  if (!config.clickhouseUrl) throw httpError(503, "CLICKHOUSE_URL is missing in .env.");
  const sql = fs.readFileSync(config.sqlFile, "utf8").trim().replace(/;+\s*$/, "");
  const query = `${sql}\nLIMIT ${limit}\nFORMAT JSONEachRow`;
  const url = new URL(config.clickhouseUrl);
  if (config.clickhouseDatabase) url.searchParams.set("database", config.clickhouseDatabase);

  const headers = { "content-type": "text/plain; charset=utf-8" };
  if (config.clickhouseUser) headers["x-clickhouse-user"] = config.clickhouseUser;
  if (config.clickhousePassword) headers["x-clickhouse-key"] = config.clickhousePassword;

  const response = await fetch(url, { method: "POST", headers, body: query });
  const text = await response.text();

  if (!response.ok) {
    throw httpError(response.status, `ClickHouse query failed: ${response.status} ${text.slice(0, 220)}`);
  }

  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => JSON.parse(line));
}

function readFileExport(limit) {
  if (!config.fileExport) throw httpError(503, "HIGH_RISK_FILE_EXPORT is missing for file provider.");
  const text = fs.readFileSync(config.fileExport, "utf8");
  const ext = path.extname(config.fileExport).toLowerCase();
  const rows = ext === ".json" ? rowsFromJson(JSON.parse(text)) : parseCsvObjects(text);
  return rows.slice(0, limit);
}

function filterRowsByDate(rows, filter) {
  if (!filter || filter === "all") return rows;
  if (filter !== "today") throw httpError(400, "Unsupported date filter. Use today or all.");

  const today = dateKeyInTimezone(new Date(), config.timezone);
  return rows.filter((row) => rowDateKey(row) === today);
}

function rowDateKey(row) {
  const value =
    row.order_purchase_at ??
    row.orderPurchaseAt ??
    row.purchase_at ??
    row.created_at ??
    row.createdAt;
  return dateKeyInTimezone(value, config.timezone);
}

function dateKeyInTimezone(value, timezone) {
  if (!value) return "";
  if (typeof value === "string") {
    const match = value.trim().match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (match) {
      const [, year, month, day] = match;
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }
  }

  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(date);
  const byType = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${byType.year}-${byType.month}-${byType.day}`;
}

function rowsFromJson(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value.data)) return value.data;
  if (Array.isArray(value.results)) return value.results;
  const tabular = Array.isArray(value?.data?.rows) ? value.data : Array.isArray(value?.rows) ? value : null;
  if (!tabular) throw httpError(400, "JSON export structure is not supported.");
  const headers = (tabular.cols || tabular.columns || []).map((column) => (typeof column === "string" ? column : column.name || column.display_name || ""));
  return tabular.rows.map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index]])));
}

function parseCsvObjects(text) {
  const rows = parseCsvRows(text);
  if (!rows.length) return [];
  const headers = rows[0].map((header) => String(header || "").replace(/^\uFEFF/, "").trim());
  return rows.slice(1).map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index] || ""])));
}

function parseCsvRows(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        cell += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === "," && !inQuotes) {
      row.push(cell);
      cell = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell);
      if (row.some((item) => String(item).trim() !== "")) rows.push(row);
      row = [];
      cell = "";
      continue;
    }

    cell += char;
  }

  row.push(cell);
  if (row.some((item) => String(item).trim() !== "")) rows.push(row);
  return rows;
}

async function serveStatic(urlPath, res) {
  const cleanPath = decodeURIComponent(urlPath === "/" ? "/index.html" : urlPath);
  const target = path.resolve(rootDir, `.${cleanPath}`);
  if (!target.startsWith(rootDir) || target.startsWith(backendDir)) throw httpError(404, "Not found");
  if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) throw httpError(404, "Not found");
  const ext = path.extname(target).toLowerCase();
  res.writeHead(200, { "content-type": mimeTypes[ext] || "application/octet-stream" });
  fs.createReadStream(target).pipe(res);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function setCommonHeaders(res) {
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type,x-metabase-session");
  res.setHeader("cache-control", "no-store");
}

function loadEnv(filePath) {
  if (!fs.existsSync(filePath)) return;
  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || !trimmed.includes("=")) continue;
    const [key, ...rest] = trimmed.split("=");
    if (process.env[key]) continue;
    process.env[key] = rest.join("=").trim().replace(/^["']|["']$/g, "");
  }
}

function trimSlash(value) {
  return String(value || "").replace(/\/+$/, "");
}

function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.max(min, Math.min(max, Math.round(value)));
}

function httpError(statusCode, message) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

async function safeText(response) {
  try {
    return await response.text();
  } catch {
    return "";
  }
}
