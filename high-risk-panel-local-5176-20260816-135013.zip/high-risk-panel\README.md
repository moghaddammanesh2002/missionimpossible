# High Risk Panel Backend

Run locally:

```bash
node server.js
```

Main endpoints:

- `GET /` serves the panel.
- `GET /api/health` shows backend configuration status.
- `GET /api/orders` returns today's rows for the panel by default.
- `GET /api/orders?date=all` returns all rows from the live query.

The query lives in:

```text
backend/high-risk-priority.sql
```

Set `.env` from `.env.example`.

Production data options:

- `HIGH_RISK_DATA_PROVIDER=clickhouse` runs the SQL file directly with ClickHouse credentials.
- `HIGH_RISK_DATA_PROVIDER=metabase` queries Metabase question `105017` with a Metabase session token or username/password.
- `HIGH_RISK_DATA_PROVIDER=file` is only for local QA.
