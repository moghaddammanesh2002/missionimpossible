WITH
    now('Asia/Tehran') AS score_at,
    60 AS max_open_age_days,
    90 AS history_days,
    180 AS customer_history_days,
    14 AS chat_lookback_days,
    1000000.0 AS min_business_gmv_toman,
    100000.0 AS min_business_commission_toman,
    0.12 AS high_commission_rate,
    50000.0 AS min_high_rate_commission_toman,
    5000000.0 AS high_business_gmv_toman,
    10000000.0 AS critical_business_gmv_toman,
    500000.0 AS high_business_commission_toman,
    1000000.0 AS critical_business_commission_toman,

recent_sales AS
(
    SELECT
        item_id,
        order_id,
        customer_id,
        product_id,
        vendor_id,
        vendor_user_id,
        category_id,
        purchase_at,
        gmv,
        quantity,
        price,
        commission,
        satisfaction_commission,
        delivery_cost,
        basalam_discount,
        vendor_discount,
        coupon_id,
        product_preparation_days_at_purchase,
        product_age,
        vendor_age,
        customer_age,
        customer_order_number,
        final_status,
        seen_at,
        vendor_approved_at,
        sent_at,
        problem_at,
        problem_reason_id,
        estimated_send_date,
        cancellation_request_at,
        cancellation_of_cancellation_request_at,
        vendor_title,
        product_title_at_purchase
    FROM OLAPBasalam.model_sales AS ms FINAL
    PREWHERE ms.purchase_at >= score_at - toIntervalDay(max_open_age_days)
         AND ms.purchase_at < score_at
    WHERE ms.order_id IS NOT NULL
      AND ifNull(ms.is_fraud, 0) = 0
),

open_order_ids AS
(
    SELECT order_id
    FROM recent_sales
    GROUP BY order_id
    HAVING countIf(final_status IS NULL AND sent_at IS NULL) > 0
),

open_sales AS
(
    SELECT *
    FROM recent_sales AS rs
    INNER JOIN open_order_ids USING (order_id)
),

order_base AS
(
    SELECT
        order_id,
        min(purchase_at) AS order_purchase_at,
        any(customer_id) AS customer_id,
        sum(ifNull(gmv, 0)) AS order_gmv_rial,
        sumIf(ifNull(gmv, 0), final_status IS NULL AND sent_at IS NULL) AS open_gmv_rial,
        sum(ifNull(commission, 0)) AS order_commission_rial,
        sumIf(ifNull(commission, 0), final_status IS NULL AND sent_at IS NULL) AS open_commission_rial,
        sumIf(ifNull(satisfaction_commission, 0), final_status IS NULL AND sent_at IS NULL) AS open_satisfaction_commission_rial,
        sumIf(ifNull(delivery_cost, 0), final_status IS NULL AND sent_at IS NULL) AS open_delivery_cost_rial,
        sum(ifNull(basalam_discount, 0)) AS basalam_discount_rial,
        sum(ifNull(vendor_discount, 0)) AS vendor_discount_rial,
        count() AS order_item_rows,
        countIf(final_status IS NULL AND sent_at IS NULL) AS open_item_rows,
        sumIf(ifNull(quantity, 0), final_status IS NULL AND sent_at IS NULL) AS open_units,
        uniqExactIf(product_id, final_status IS NULL AND sent_at IS NULL) AS open_product_count,
        uniqExactIf(vendor_id, final_status IS NULL AND sent_at IS NULL) AS open_vendor_count,
        maxIf(ifNull(price, 0), final_status IS NULL AND sent_at IS NULL) AS max_open_item_price_rial,
        maxIf(ifNull(product_preparation_days_at_purchase, 3), final_status IS NULL AND sent_at IS NULL) AS max_preparation_days,
        avgIf(product_age, final_status IS NULL AND product_age IS NOT NULL) AS avg_product_age_days,
        avgIf(vendor_age, final_status IS NULL AND vendor_age IS NOT NULL) AS avg_vendor_age_days,
        max(customer_age) AS customer_age_days,
        max(customer_order_number) AS customer_order_number,
        argMax(category_id, ifNull(gmv, 0)) AS dominant_category_id,
        arrayStringConcat(arrayMap(x -> toString(x), groupUniqArrayIf(vendor_id, final_status IS NULL AND sent_at IS NULL)), ',') AS vendor_ids,
        arrayStringConcat(groupUniqArrayIf(vendor_title, final_status IS NULL AND sent_at IS NULL), ' | ') AS vendor_titles,
        countIf(final_status IS NULL AND sent_at IS NULL AND seen_at IS NULL) > 0 AS has_unseen_open_item,
        countIf(final_status IS NULL AND sent_at IS NULL AND vendor_approved_at IS NULL) > 0 AS has_unapproved_open_item,
        countIf(final_status IS NULL AND sent_at IS NULL) > 0 AS has_unsent_open_item,
        countIf(
            final_status IS NULL
            AND sent_at IS NULL
            AND score_at > purchase_at + toIntervalDay(greatest(ifNull(product_preparation_days_at_purchase, 3), 0))
        ) > 0 AS has_past_due_open_item,
        countIf(final_status IS NULL AND sent_at IS NULL AND problem_at IS NOT NULL) > 0 AS has_problem,
        countIf(
            final_status IS NULL
            AND sent_at IS NULL
            AND notEmpty(cancellation_request_at)
            AND arrayMax(cancellation_request_at) <= score_at
            AND (
                empty(cancellation_of_cancellation_request_at)
                OR arrayMax(cancellation_request_at) > arrayMax(cancellation_of_cancellation_request_at)
            )
        ) > 0 AS has_active_cancel_request,
        minIf(seen_at, final_status IS NULL AND sent_at IS NULL AND seen_at IS NOT NULL) AS first_seen_at,
        minIf(vendor_approved_at, final_status IS NULL AND sent_at IS NULL AND vendor_approved_at IS NOT NULL) AS first_vendor_approved_at,
        maxIf(estimated_send_date, final_status IS NULL AND sent_at IS NULL AND estimated_send_date IS NOT NULL) AS estimated_send_date,
        maxIf(
            purchase_at + toIntervalDay(greatest(ifNull(product_preparation_days_at_purchase, 3), 0)),
            final_status IS NULL AND sent_at IS NULL
        ) AS preparation_due_at,
        max(coupon_id IS NOT NULL) AS has_coupon
    FROM open_sales
    GROUP BY order_id
),

vendor_history AS
(
    SELECT
        ms.vendor_id,
        uniqExact(ms.order_id) AS vendor_hist_orders,
        count() AS vendor_hist_item_rows,
        countIf(ms.is_cancelled = 1) / nullIf(count(), 0) AS vendor_cancel_rate,
        (
            (countIf(ms.is_cancelled = 1) / nullIf(count(), 0)) * uniqExact(ms.order_id)
            + 0.12 * 30.0
        ) / (uniqExact(ms.order_id) + 30.0) AS vendor_smoothed_cancel_rate,
        countIf(ms.is_cancelled = 1 AND cf.fault_title_Fa = 'غرفه‌دار') / nullIf(count(), 0) AS vendor_fault_cancel_rate,
        countIf(ms.is_cancelled = 1 AND ms.cancellation_reason_id = 4440) / nullIf(count(), 0) AS vendor_no_approve_rate,
        countIf(ms.is_cancelled = 1 AND ms.cancellation_reason_id = 3474) / nullIf(count(), 0) AS vendor_out_of_stock_rate,
        countIf(ms.is_cancelled = 1 AND ms.cancellation_reason_id = 3475) / nullIf(count(), 0) AS vendor_delay_rate,
        countIf(ms.is_cancelled = 1 AND ms.cancellation_reason_id = 3473) / nullIf(count(), 0) AS vendor_price_error_rate,
        avgIf(
            dateDiff('hour', ms.purchase_at, ms.seen_at),
            ms.seen_at IS NOT NULL AND ms.seen_at >= ms.purchase_at
        ) AS vendor_avg_seen_hours,
        avgIf(
            dateDiff('hour', ms.purchase_at, ms.vendor_approved_at),
            ms.vendor_approved_at IS NOT NULL AND ms.vendor_approved_at >= ms.purchase_at
        ) AS vendor_avg_approve_hours,
        dateDiff('day', max(ms.purchase_at), score_at) AS vendor_recency_days
    FROM OLAPBasalam.model_sales AS ms FINAL
    LEFT JOIN OLAPBasalam.dim_cancellation_fault AS cf
        ON ms.cancellation_reason_id = cf.cancellation_reason_id
       AND ms.cancelled_by_id = cf.canceller_id
    PREWHERE ms.purchase_at >= score_at - toIntervalDay(history_days)
         AND ms.purchase_at < score_at
    WHERE ms.order_id IS NOT NULL
      AND ms.final_status IS NOT NULL
      AND ifNull(ms.is_fraud, 0) = 0
    GROUP BY ms.vendor_id
),

customer_history AS
(
    SELECT
        ms.customer_id,
        uniqExact(ms.order_id) AS customer_hist_orders,
        countIf(ms.is_cancelled = 1) / nullIf(count(), 0) AS customer_cancel_item_rate,
        countIf(ms.is_cancelled = 1 AND cf.fault_title_Fa = 'مشتری') / nullIf(count(), 0) AS customer_fault_cancel_rate,
        avg(ms.gmv) AS customer_avg_item_gmv_rial,
        dateDiff('day', max(ms.purchase_at), score_at) AS customer_recency_days
    FROM OLAPBasalam.model_sales AS ms FINAL
    LEFT JOIN OLAPBasalam.dim_cancellation_fault AS cf
        ON ms.cancellation_reason_id = cf.cancellation_reason_id
       AND ms.cancelled_by_id = cf.canceller_id
    PREWHERE ms.purchase_at >= score_at - toIntervalDay(customer_history_days)
         AND ms.purchase_at < score_at
    WHERE ms.customer_id IS NOT NULL
      AND ms.order_id IS NOT NULL
      AND ms.final_status IS NOT NULL
      AND ifNull(ms.is_fraud, 0) = 0
    GROUP BY ms.customer_id
),

category_history AS
(
    SELECT
        ms.category_id,
        countIf(ms.is_cancelled = 1) / nullIf(count(), 0) AS category_cancel_rate,
        countIf(ms.is_cancelled = 1 AND cf.fault_title_Fa = 'غرفه‌دار') / nullIf(count(), 0) AS category_vendor_fault_rate
    FROM OLAPBasalam.model_sales AS ms FINAL
    LEFT JOIN OLAPBasalam.dim_cancellation_fault AS cf
        ON ms.cancellation_reason_id = cf.cancellation_reason_id
       AND ms.cancelled_by_id = cf.canceller_id
    PREWHERE ms.purchase_at >= score_at - toIntervalDay(history_days)
         AND ms.purchase_at < score_at
    WHERE ms.category_id IS NOT NULL
      AND ms.order_id IS NOT NULL
      AND ms.final_status IS NOT NULL
      AND ifNull(ms.is_fraud, 0) = 0
    GROUP BY ms.category_id
),

open_category_map AS
(
    SELECT DISTINCT order_id, category_id
    FROM open_sales
    WHERE final_status IS NULL
      AND sent_at IS NULL
      AND category_id IS NOT NULL
),

order_category_features AS
(
    SELECT
        oc.order_id,
        max(ch.category_cancel_rate) AS max_category_cancel_rate,
        max(ch.category_vendor_fault_rate) AS max_category_vendor_fault_rate
    FROM open_category_map AS oc
    LEFT JOIN category_history AS ch USING (category_id)
    GROUP BY oc.order_id
),

open_vendor_ids AS
(
    SELECT DISTINCT vendor_id
    FROM open_sales
    WHERE final_status IS NULL
      AND sent_at IS NULL
),

vendor_quality_metrics AS
(
    SELECT
        ms.vendor_id,
        uniqExact(ms.order_id) AS quality_orders_count,
        count() AS quality_items_count,
        uniqExactIf(ms.order_id, ms.postpone_days > 0) AS postponed_orders,
        countIf(
            ms.is_cancelled = 1
            AND ms.cancellation_reason_id NOT IN (4635, 4637, 4639, 3478, 4099, 4641, 4638, 4636, 3573, 4444)
        ) AS vendor_cancelled_items,
        countIf(
            ms.has_problem = 1
            AND arrayExists(status_id -> status_id IN (3128, 3129, 3449, 3484, 5017, 6070), ms.problem_status_list)
        ) AS problemed_items
    FROM OLAPBasalam.model_sales AS ms
    INNER JOIN open_vendor_ids AS ovi USING (vendor_id)
    PREWHERE ms.purchase_at >= score_at - INTERVAL 30 DAY
         AND ms.purchase_at < score_at
    WHERE ms.order_id IS NOT NULL
      AND (ms.sent_at IS NOT NULL OR ms.canceled_at IS NOT NULL)
      AND ifNull(ms.is_fraud, 0) = 0
    GROUP BY ms.vendor_id
),

vendor_quality AS
(
    SELECT
        *,
        round(
            (
                50.0 * (100.0 - 100.0 * vendor_cancelled_items / nullIf(quality_items_count, 0))
                + 35.0 * (100.0 - 100.0 * problemed_items / nullIf(quality_items_count, 0))
                + 15.0 * (100.0 - 100.0 * postponed_orders / nullIf(quality_orders_count, 0))
            ) / 100.0,
            1
        ) AS vendor_overall_score,
        multiIf(
            quality_orders_count <= 5, 'فروش کم',
            vendor_overall_score >= 99, 'عالی',
            vendor_overall_score >= 98, 'خوب',
            vendor_overall_score >= 95, 'متوسط',
            'ضعیف'
        ) AS vendor_quality_label
    FROM vendor_quality_metrics
),

order_vendor_map AS
(
    SELECT DISTINCT order_id, vendor_id
    FROM open_sales
    WHERE final_status IS NULL
      AND sent_at IS NULL
),

order_vendor_quality AS
(
    SELECT
        ov.order_id,
        min(ifNull(vq.vendor_overall_score, 0)) AS min_vendor_quality_score,
        arrayStringConcat(groupUniqArray(ifNull(vq.vendor_quality_label, 'فروش کم')), ' | ') AS vendor_quality_labels,
        countIf(ifNull(vq.vendor_quality_label, 'فروش کم') != 'عالی') = 0 AS all_vendors_excellent
    FROM order_vendor_map AS ov
    LEFT JOIN vendor_quality AS vq USING (vendor_id)
    GROUP BY ov.order_id
),

order_vendor_features AS
(
    SELECT
        ov.order_id,
        max(vh.vendor_hist_orders) AS max_vendor_hist_orders,
        avg(vh.vendor_cancel_rate) AS avg_vendor_cancel_rate,
        max(vh.vendor_cancel_rate) AS max_vendor_cancel_rate,
        max(vh.vendor_smoothed_cancel_rate) AS max_vendor_smoothed_cancel_rate,
        max(vh.vendor_fault_cancel_rate) AS max_vendor_fault_cancel_rate,
        max(vh.vendor_no_approve_rate) AS max_vendor_no_approve_rate,
        max(vh.vendor_out_of_stock_rate) AS max_vendor_out_of_stock_rate,
        max(vh.vendor_delay_rate) AS max_vendor_delay_rate,
        max(vh.vendor_price_error_rate) AS max_vendor_price_error_rate,
        max(vh.vendor_avg_seen_hours) AS max_vendor_avg_seen_hours,
        max(vh.vendor_avg_approve_hours) AS max_vendor_avg_approve_hours,
        max(vh.vendor_recency_days) AS max_vendor_recency_days
    FROM order_vendor_map AS ov
    LEFT JOIN vendor_history AS vh USING (vendor_id)
    GROUP BY ov.order_id
),

open_product_map AS
(
    SELECT DISTINCT order_id, product_id
    FROM open_sales
    WHERE final_status IS NULL
      AND sent_at IS NULL
      AND product_id IS NOT NULL
),

latest_open_products_raw AS
(
    SELECT
        product_id,
        argMax(
            tuple(inventory, isInStock, isAvailable, last_modified_at),
            version
        ) AS latest_record
    FROM OLAPBasalam.dim_product_dist
    WHERE product_id IN (SELECT product_id FROM open_product_map)
    GROUP BY product_id
),

latest_open_products AS
(
    SELECT
        product_id,
        tupleElement(latest_record, 1) AS current_inventory,
        tupleElement(latest_record, 2) AS current_is_in_stock,
        tupleElement(latest_record, 3) AS current_is_available,
        tupleElement(latest_record, 4) AS product_last_modified_at
    FROM latest_open_products_raw
),

order_product_state AS
(
    SELECT
        op.order_id,
        countIf(p.product_id IS NULL) > 0 AS has_missing_product_state,
        countIf(
            p.product_id IS NOT NULL
            AND (ifNull(p.current_inventory, 0) <= 0 OR ifNull(p.current_is_in_stock, 0) = 0)
        ) > 0 AS has_current_stock_problem,
        countIf(p.product_id IS NOT NULL AND ifNull(p.current_is_available, 0) = 0) > 0 AS has_current_unavailable_product,
        maxIf(dateDiff('day', p.product_last_modified_at, score_at), p.product_last_modified_at IS NOT NULL) AS max_product_update_age_days
    FROM open_product_map AS op
    LEFT JOIN latest_open_products AS p USING (product_id)
    GROUP BY op.order_id
),

target_chat_pairs AS
(
    SELECT
        os.order_id,
        min(os.purchase_at) AS order_purchase_at,
        any(os.customer_id) AS customer_user_id,
        os.vendor_user_id,
        least(any(os.customer_id), os.vendor_user_id) AS user_low,
        greatest(any(os.customer_id), os.vendor_user_id) AS user_high
    FROM open_sales AS os
    WHERE os.final_status IS NULL
      AND os.sent_at IS NULL
      AND os.customer_id IS NOT NULL
      AND os.vendor_user_id IS NOT NULL
    GROUP BY os.order_id, os.vendor_user_id
),

chat_filtered AS
(
    SELECT
        id,
        sender,
        user_one,
        user_two,
        created_at,
        message
    FROM ods.chats
    PREWHERE created_at >= score_at - toIntervalDay(chat_lookback_days)
         AND created_at < score_at
    WHERE deleted_at IS NULL
),

order_chat AS
(
    SELECT
        tp.order_id,
        countIf(c.id != 0) AS chat_messages,
        countIf(c.id != 0 AND c.sender = tp.customer_user_id) AS customer_chat_messages,
        countIf(c.id != 0 AND c.sender = tp.vendor_user_id) AS vendor_chat_messages,
        maxIf(c.created_at, c.id != 0 AND c.sender = tp.customer_user_id) AS last_customer_message_at,
        maxIf(c.created_at, c.id != 0 AND c.sender = tp.vendor_user_id) AS last_vendor_message_at,
        countIf(
            c.id != 0
            AND (
                positionUTF8(ifNull(c.message, ''), 'کنسل') > 0
                OR positionUTF8(ifNull(c.message, ''), 'لغو') > 0
            )
        ) AS cancel_keyword_messages,
        countIf(
            c.id != 0
            AND (
                positionUTF8(ifNull(c.message, ''), 'موجود') > 0
                OR positionUTF8(ifNull(c.message, ''), 'ناموجود') > 0
            )
        ) AS inventory_keyword_messages,
        countIf(
            c.id != 0
            AND (
                positionUTF8(ifNull(c.message, ''), 'ارسال') > 0
                OR positionUTF8(ifNull(c.message, ''), 'تاخیر') > 0
                OR positionUTF8(ifNull(c.message, ''), 'دیر') > 0
            )
        ) AS shipping_keyword_messages,
        countIf(
            c.id != 0
            AND (
                positionUTF8(ifNull(c.message, ''), 'قیمت') > 0
                OR positionUTF8(ifNull(c.message, ''), 'مبلغ') > 0
                OR positionUTF8(ifNull(c.message, ''), 'افزایش') > 0
                OR positionUTF8(ifNull(c.message, ''), 'گرون') > 0
            )
        ) AS price_keyword_messages,
        countIf(
            c.id != 0
            AND c.sender = tp.customer_user_id
            AND (
                positionUTF8(ifNull(c.message, ''), 'لغو کنید') > 0
                OR positionUTF8(ifNull(c.message, ''), 'لغو سفارش') > 0
                OR positionUTF8(ifNull(c.message, ''), 'کنسل کنید') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نمیخوام') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نمی‌خوام') > 0
            )
        ) AS explicit_cancel_phrase_messages,
        countIf(
            c.id != 0
            AND c.sender = tp.vendor_user_id
            AND (
                positionUTF8(ifNull(c.message, ''), 'موجود نیست') > 0
                OR positionUTF8(ifNull(c.message, ''), 'تموم شده') > 0
                OR positionUTF8(ifNull(c.message, ''), 'ناموجود') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نداریم') > 0
                OR positionUTF8(ifNull(c.message, ''), 'ندارم') > 0
            )
        ) AS explicit_stockout_phrase_messages,
        countIf(
            c.id != 0
            AND c.sender = tp.vendor_user_id
            AND (
                positionUTF8(ifNull(c.message, ''), 'متاسفانه') > 0
                OR positionUTF8(ifNull(c.message, ''), 'متأسفانه') > 0
                OR positionUTF8(ifNull(c.message, ''), 'شرمنده') > 0
                OR positionUTF8(ifNull(c.message, ''), 'عذر') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نمیتونم') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نمی‌تونم') > 0
            )
        ) AS vendor_inability_phrase_messages,
        countIf(
            c.id != 0
            AND c.sender = tp.customer_user_id
            AND (
                positionUTF8(ifNull(c.message, ''), 'نمیفرستی') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نمی‌فرستی') > 0
                OR positionUTF8(ifNull(c.message, ''), 'نفرستادی') > 0
                OR positionUTF8(ifNull(c.message, ''), 'ارسال نکرد') > 0
                OR positionUTF8(ifNull(c.message, ''), 'هنوز ارسال') > 0
                OR positionUTF8(ifNull(c.message, ''), 'جواب نمید') > 0
            )
        ) AS no_send_or_no_response_phrase_messages,
        countIf(
            c.id != 0
            AND (
                positionUTF8(ifNull(c.message, ''), 'جایگزین') > 0
                OR positionUTF8(ifNull(c.message, ''), 'تغییر') > 0
                OR positionUTF8(ifNull(c.message, ''), 'چه سایزی') > 0
                OR positionUTF8(ifNull(c.message, ''), 'چه رنگی') > 0
            )
        ) AS replacement_or_change_phrase_messages
    FROM target_chat_pairs AS tp
    LEFT JOIN chat_filtered AS c
        ON least(c.user_one, c.user_two) = tp.user_low
       AND greatest(c.user_one, c.user_two) = tp.user_high
       AND c.created_at >= greatest(tp.order_purchase_at, score_at - toIntervalDay(chat_lookback_days))
       AND c.created_at < score_at
    GROUP BY tp.order_id
),

assembled AS
(
    SELECT
        ob.order_id AS order_id,
        ob.customer_id AS customer_id,
        ob.* EXCEPT (order_id, customer_id),
        ifNull(ch.customer_hist_orders, 0) AS customer_hist_orders,
        ifNull(ch.customer_cancel_item_rate, 0.12) AS customer_cancel_item_rate,
        ifNull(ch.customer_fault_cancel_rate, 0.08) AS customer_fault_cancel_rate,
        ifNull(ch.customer_avg_item_gmv_rial, 0) AS customer_avg_item_gmv_rial,
        ifNull(ch.customer_recency_days, customer_history_days) AS customer_recency_days,
        ifNull(ov.max_vendor_hist_orders, 0) AS max_vendor_hist_orders,
        ifNull(ov.avg_vendor_cancel_rate, 0.12) AS avg_vendor_cancel_rate,
        ifNull(ov.max_vendor_cancel_rate, 0.12) AS max_vendor_cancel_rate,
        ifNull(ov.max_vendor_smoothed_cancel_rate, 0.12) AS max_vendor_smoothed_cancel_rate,
        ifNull(ov.max_vendor_fault_cancel_rate, 0.08) AS max_vendor_fault_cancel_rate,
        ifNull(ov.max_vendor_no_approve_rate, 0.02) AS max_vendor_no_approve_rate,
        ifNull(ov.max_vendor_out_of_stock_rate, 0.02) AS max_vendor_out_of_stock_rate,
        ifNull(ov.max_vendor_delay_rate, 0.02) AS max_vendor_delay_rate,
        ifNull(ov.max_vendor_price_error_rate, 0.01) AS max_vendor_price_error_rate,
        ifNull(ov.max_vendor_avg_seen_hours, 24) AS max_vendor_avg_seen_hours,
        ifNull(ov.max_vendor_avg_approve_hours, 24) AS max_vendor_avg_approve_hours,
        ifNull(ov.max_vendor_recency_days, 30) AS max_vendor_recency_days,
        ifNull(ovq.min_vendor_quality_score, 0) AS min_vendor_quality_score,
        ifNull(ovq.vendor_quality_labels, 'فروش کم') AS vendor_quality_labels,
        ifNull(ovq.all_vendors_excellent, 0) AS all_vendors_excellent,
        ifNull(cat.max_category_cancel_rate, 0.12) AS category_cancel_rate,
        ifNull(cat.max_category_vendor_fault_rate, 0.08) AS category_vendor_fault_rate,
        ifNull(ps.has_missing_product_state, 0) AS has_missing_product_state,
        ifNull(ps.has_current_stock_problem, 0) AS has_current_stock_problem,
        ifNull(ps.has_current_unavailable_product, 0) AS has_current_unavailable_product,
        ifNull(ps.max_product_update_age_days, 30) AS max_product_update_age_days,
        ifNull(oc.chat_messages, 0) AS chat_messages,
        ifNull(oc.customer_chat_messages, 0) AS customer_chat_messages,
        ifNull(oc.vendor_chat_messages, 0) AS vendor_chat_messages,
        oc.last_customer_message_at,
        oc.last_vendor_message_at,
        ifNull(oc.cancel_keyword_messages, 0) AS cancel_keyword_messages,
        ifNull(oc.inventory_keyword_messages, 0) AS inventory_keyword_messages,
        ifNull(oc.shipping_keyword_messages, 0) AS shipping_keyword_messages,
        ifNull(oc.price_keyword_messages, 0) AS price_keyword_messages,
        ifNull(oc.explicit_cancel_phrase_messages, 0) AS explicit_cancel_phrase_messages,
        ifNull(oc.explicit_stockout_phrase_messages, 0) AS explicit_stockout_phrase_messages,
        ifNull(oc.vendor_inability_phrase_messages, 0) AS vendor_inability_phrase_messages,
        ifNull(oc.no_send_or_no_response_phrase_messages, 0) AS no_send_or_no_response_phrase_messages,
        ifNull(oc.replacement_or_change_phrase_messages, 0) AS replacement_or_change_phrase_messages
    FROM order_base AS ob
    LEFT JOIN customer_history AS ch USING (customer_id)
    LEFT JOIN order_vendor_features AS ov USING (order_id)
    LEFT JOIN order_vendor_quality AS ovq USING (order_id)
    LEFT JOIN order_category_features AS cat USING (order_id)
    LEFT JOIN order_product_state AS ps USING (order_id)
    LEFT JOIN order_chat AS oc USING (order_id)
),

risk_inputs AS
(
    SELECT
        *,
        dateDiff('minute', order_purchase_at, score_at) AS order_age_minutes,
        dateDiff('hour', order_purchase_at, score_at) AS order_age_hours,
        dateDiff('day', order_purchase_at, score_at) AS order_age_days,
        has_past_due_open_item AS is_past_preparation_sla,
        open_commission_rial / nullIf(open_gmv_rial, 0) AS open_commission_rate,
        least(
            ifNull(open_commission_rial / nullIf(open_gmv_rial, 0), 0) / high_commission_rate,
            1.0
        ) AS commission_rate_score_0_1,
        (
            open_gmv_rial >= min_business_gmv_toman * 10.0
            OR open_commission_rial >= min_business_commission_toman * 10.0
            OR (
                open_commission_rial >= min_high_rate_commission_toman * 10.0
                AND ifNull(open_commission_rial / nullIf(open_gmv_rial, 0), 0) >= high_commission_rate
            )
        ) AS business_value_eligible,
        customer_chat_messages > 0
            AND (
                vendor_chat_messages = 0
                OR last_customer_message_at > last_vendor_message_at
            ) AS has_unanswered_customer_chat,
        max_vendor_smoothed_cancel_rate AS smoothed_max_vendor_cancel_rate
    FROM assembled
),

base_scored AS
(
    SELECT
        *,
        0.35 * smoothed_max_vendor_cancel_rate
        + 0.10 * max_vendor_cancel_rate
        + 0.10 * max_vendor_fault_cancel_rate
        + 0.08 * max_vendor_no_approve_rate
        + 0.05 * max_vendor_delay_rate
        + 0.05 * max_vendor_out_of_stock_rate
        + 0.05 * least(toFloat64(max_vendor_avg_approve_hours) / 48.0, 2.0)
        + 0.03 * least(toFloat64(max_vendor_avg_seen_hours) / 48.0, 2.0)
        + 0.03 * least(toFloat64(max_vendor_recency_days) / 90.0, 2.0)
        + 0.04 * category_cancel_rate
        + 0.03 * customer_cancel_item_rate
        + 0.02 * least(toFloat64(open_vendor_count) / 3.0, 2.0)
        + 0.02 * least(toFloat64(max_preparation_days) / 30.0, 2.0) AS base_risk_raw
    FROM risk_inputs
),

probability_inputs AS
(
    SELECT
        *,
        multiIf(
            base_risk_raw < 0.03656342, 0.02980201,
            base_risk_raw < 0.04402761, 0.04382191,
            base_risk_raw < 0.05121046, 0.05374798,
            base_risk_raw < 0.05850900, 0.06661484,
            base_risk_raw < 0.06678840, 0.08348558,
            base_risk_raw < 0.07797663, 0.09777778,
            base_risk_raw < 0.09424049, 0.11835439,
            base_risk_raw < 0.11900000, 0.15055394,
            base_risk_raw < 0.15735836, 0.22401037,
            0.36834467
        ) AS initial_cancel_probability,
        multiIf(
            order_age_hours < 6, 1.0,
            order_age_hours < 24, 0.62,
            order_age_hours < 72, 0.25,
            order_age_hours < 168, 0.17,
            0.10
        ) AS survival_odds_factor,
        least(
            25.0,
            if(has_active_cancel_request, 7.0, 1.0)
            * if(order_age_hours >= 6 AND order_age_hours < 24 AND has_unapproved_open_item, 5.0, 1.0)
            * if(order_age_hours >= 6 AND order_age_hours < 24 AND has_unseen_open_item, 1.6, 1.0)
            * if(order_age_hours >= 24 AND order_age_hours < 72 AND has_unsent_open_item, 1.35, 1.0)
            * if(order_age_hours >= 72 AND has_unsent_open_item, 3.0, 1.0)
            * if(is_past_preparation_sla, 1.60, 1.0)
            * if(has_problem, 1.30, 1.0)
            * if(has_unanswered_customer_chat, 1.85, 1.0)
            * if(cancel_keyword_messages > 0, 1.50, 1.0)
            * if(inventory_keyword_messages > 0, 1.35, 1.0)
            * if(shipping_keyword_messages > 0, 1.25, 1.0)
            * if(price_keyword_messages > 0, 1.20, 1.0)
            * if(explicit_cancel_phrase_messages > 0, 6.0, 1.0)
            * if(explicit_stockout_phrase_messages > 0, 4.0, 1.0)
            * if(vendor_inability_phrase_messages > 0, 2.5, 1.0)
            * if(no_send_or_no_response_phrase_messages > 0, 2.5, 1.0)
            * if(replacement_or_change_phrase_messages > 0, 1.4, 1.0)
            * if(has_current_stock_problem OR has_current_unavailable_product, 1.70, 1.0)
        ) AS evidence_odds_multiplier
    FROM base_scored
),

dynamic_scored AS
(
    SELECT
        *,
        least(
            0.99,
            (
                initial_cancel_probability
                / greatest(1.0 - initial_cancel_probability, 0.0001)
                * survival_odds_factor
                * evidence_odds_multiplier
            )
            /
            (
                1.0
                + initial_cancel_probability
                / greatest(1.0 - initial_cancel_probability, 0.0001)
                * survival_odds_factor
                * evidence_odds_multiplier
            )
        ) AS dynamic_cancel_probability,
        (
            has_active_cancel_request
            OR has_unanswered_customer_chat
            OR explicit_cancel_phrase_messages > 0
            OR explicit_stockout_phrase_messages > 0
            OR vendor_inability_phrase_messages > 0
            OR no_send_or_no_response_phrase_messages > 0
            OR inventory_keyword_messages > 0
            OR shipping_keyword_messages > 0
            OR price_keyword_messages > 0
            OR replacement_or_change_phrase_messages > 0
            OR has_current_stock_problem
            OR has_current_unavailable_product
            OR is_past_preparation_sla
            OR has_problem
            OR (order_age_hours >= 6 AND has_unapproved_open_item)
        ) AS has_specific_reason_evidence,
        5.0 * toFloat64(has_active_cancel_request)
            + 2.0 * toFloat64(has_unanswered_customer_chat)
            + 2.0 * toFloat64(cancel_keyword_messages > 0)
            + 5.0 * toFloat64(explicit_cancel_phrase_messages > 0)
            + 1.5 * toFloat64(replacement_or_change_phrase_messages > 0)
            + 3.0 * customer_fault_cancel_rate AS customer_intent_reason_score,
        5.0 * toFloat64(order_age_hours >= 6 AND order_age_hours < 24 AND has_unapproved_open_item)
            + 2.0 * toFloat64(has_unseen_open_item)
            + 3.0 * toFloat64(vendor_inability_phrase_messages > 0)
            + 3.0 * toFloat64(no_send_or_no_response_phrase_messages > 0)
            + 10.0 * max_vendor_no_approve_rate AS vendor_no_approval_reason_score,
        5.0 * toFloat64(has_current_stock_problem OR has_current_unavailable_product)
            + 3.0 * toFloat64(inventory_keyword_messages > 0)
            + 5.0 * toFloat64(explicit_stockout_phrase_messages > 0)
            + 10.0 * max_vendor_out_of_stock_rate AS inventory_reason_score,
        6.0 * toFloat64(order_age_hours >= 72 AND has_unsent_open_item)
            + 3.0 * toFloat64(order_age_hours >= 24 AND order_age_hours < 72 AND has_unsent_open_item)
            + 2.0 * toFloat64(shipping_keyword_messages > 0)
            + 4.0 * toFloat64(no_send_or_no_response_phrase_messages > 0)
            + 10.0 * max_vendor_delay_rate AS delay_reason_score,
        3.0 * toFloat64(price_keyword_messages > 0)
            + 10.0 * max_vendor_price_error_rate AS price_reason_score
    FROM probability_inputs
),

ranked AS
(
    SELECT
        *,
        percent_rank() OVER (ORDER BY dynamic_cancel_probability) AS risk_percentile_0_1,
        percent_rank() OVER (ORDER BY log1p(toFloat64(open_gmv_rial))) AS gmv_percentile_0_1,
        percent_rank() OVER (ORDER BY log1p(toFloat64(open_commission_rial))) AS commission_amount_percentile_0_1,
        percent_rank() OVER (
            ORDER BY log1p(toFloat64(customer_hist_orders) * toFloat64(customer_avg_item_gmv_rial))
        ) AS customer_value_percentile_0_1
    FROM dynamic_scored
),

importance_raw AS
(
    SELECT
        *,
        least(
            1.0,
            0.70 * gmv_percentile_0_1
            + 0.20 * commission_amount_percentile_0_1
            + 0.05 * commission_rate_score_0_1
            + 0.05 * customer_value_percentile_0_1
        ) AS business_importance_raw_0_1
    FROM ranked
),

importance_scored AS
(
    SELECT
        *,
        if(
            business_value_eligible,
            greatest(
                business_importance_raw_0_1,
                if(open_gmv_rial >= critical_business_gmv_toman * 10.0, 0.95, 0.0),
                if(open_commission_rial >= critical_business_commission_toman * 10.0, 0.95, 0.0),
                if(open_gmv_rial >= high_business_gmv_toman * 10.0, 0.90, 0.0),
                if(open_commission_rial >= high_business_commission_toman * 10.0, 0.90, 0.0),
                if(open_gmv_rial >= min_business_gmv_toman * 10.0, 0.65, 0.0),
                if(open_commission_rial >= min_business_commission_toman * 10.0, 0.65, 0.0)
            ),
            least(business_importance_raw_0_1, 0.35)
        ) AS business_importance_0_1,
        dynamic_cancel_probability * open_gmv_rial AS expected_cancelled_gmv_rial,
        dynamic_cancel_probability * open_commission_rial AS expected_lost_commission_rial
    FROM importance_raw
),

economic_ranked AS
(
    SELECT
        *,
        percent_rank() OVER (ORDER BY log1p(toFloat64(expected_cancelled_gmv_rial))) AS expected_gmv_loss_percentile_0_1,
        percent_rank() OVER (ORDER BY log1p(toFloat64(expected_lost_commission_rial))) AS expected_commission_loss_percentile_0_1
    FROM importance_scored
),

final_scored AS
(
    SELECT
        *,
        if(
            business_value_eligible,
            least(
                1.0,
                0.70 * expected_gmv_loss_percentile_0_1
                + 0.25 * expected_commission_loss_percentile_0_1
                + 0.05 * risk_percentile_0_1
            ),
            least(
                0.60,
                0.70 * expected_gmv_loss_percentile_0_1
                + 0.25 * expected_commission_loss_percentile_0_1
                + 0.05 * risk_percentile_0_1
            )
        ) AS priority_0_1,
        greatest(
            customer_intent_reason_score,
            vendor_no_approval_reason_score,
            inventory_reason_score,
            delay_reason_score,
            price_reason_score
        ) AS max_reason_score
    FROM economic_ranked
)

SELECT
    order_id,
    score_at AS scored_at,
    order_purchase_at,
    order_age_minutes,
    order_age_hours,
    order_age_days,
    customer_id,
    vendor_ids,
    vendor_titles,
    vendor_quality_labels,
    min_vendor_quality_score,
    all_vendors_excellent,
    if(
        all_vendors_excellent AND NOT has_specific_reason_evidence,
        'light_excellent_vendor',
        'full_risk_analysis'
    ) AS scoring_mode,
    (
        priority_0_1 >= 0.85
        OR dynamic_cancel_probability >= 0.40
        OR has_active_cancel_request
        OR explicit_cancel_phrase_messages > 0
        OR explicit_stockout_phrase_messages > 0
        OR has_unanswered_customer_chat
        OR has_current_stock_problem
        OR is_past_preparation_sla
        OR has_problem
    ) AS intervention_required,
    multiIf(
        business_value_eligible AND priority_0_1 >= 0.85, 'human_high_value',
        dynamic_cancel_probability >= 0.40 OR has_specific_reason_evidence, 'automated_risk_recovery',
        'monitor_only'
    ) AS intervention_mode,
    order_gmv_rial / 10.0 AS order_gmv_toman,
    open_gmv_rial / 10.0 AS open_gmv_toman,
    order_commission_rial / 10.0 AS order_commission_toman,
    open_commission_rial / 10.0 AS open_commission_toman,
    round(100.0 * ifNull(open_commission_rate, 0), 2) AS open_commission_rate_pct,
    business_value_eligible,
    expected_cancelled_gmv_rial / 10.0 AS expected_cancelled_gmv_toman,
    expected_lost_commission_rial / 10.0 AS expected_lost_commission_toman,
    open_item_rows,
    open_units,
    open_product_count,
    open_vendor_count,
    round(100.0 * dynamic_cancel_probability, 2) AS cancellation_probability_pct,
    greatest(1, least(100, toUInt8(round(100.0 * risk_percentile_0_1)))) AS risk_percentile,
    greatest(1, least(100, toUInt8(round(100.0 * business_importance_0_1)))) AS business_importance_pct,
    greatest(1, least(100, toUInt8(round(100.0 * priority_0_1)))) AS priority_pct,
    multiIf(
        dynamic_cancel_probability >= 0.70, 'R1_critical',
        dynamic_cancel_probability >= 0.40, 'R2_high',
        dynamic_cancel_probability >= 0.20, 'R3_medium',
        dynamic_cancel_probability >= 0.10, 'R4_watch',
        'R5_low'
    ) AS risk_band,
    multiIf(
        priority_0_1 >= 0.95, 'P1_critical',
        priority_0_1 >= 0.85, 'P2_high',
        priority_0_1 >= 0.65, 'P3_monitor',
        'P4_normal'
    ) AS priority_band,
    multiIf(
        NOT has_specific_reason_evidence, 'general_historical_risk',
        max_reason_score = customer_intent_reason_score, 'customer_intent_or_communication',
        max_reason_score = vendor_no_approval_reason_score, 'vendor_no_approval_or_response',
        max_reason_score = inventory_reason_score, 'inventory_or_availability',
        max_reason_score = delay_reason_score, 'delay_or_shipping',
        max_reason_score = price_reason_score, 'price_or_cost',
        'general_historical_risk'
    ) AS likely_cancel_reason_group,
    multiIf(
        NOT has_specific_reason_evidence, 'ریسک تاریخی عمومی غرفه، مشتری یا دسته‌بندی',
        max_reason_score = customer_intent_reason_score, 'پیام یا درخواست کنسلی مشتری / مسئله ارتباطی',
        max_reason_score = vendor_no_approval_reason_score, 'عدم مشاهده، پاسخ یا تأیید به‌موقع غرفه‌دار',
        max_reason_score = inventory_reason_score, 'ریسک موجودی یا در دسترس نبودن محصول',
        max_reason_score = delay_reason_score, 'ریسک تأخیر در آماده‌سازی یا ارسال',
        max_reason_score = price_reason_score, 'ریسک قیمت یا هزینه',
        'ریسک تاریخی عمومی غرفه یا دسته‌بندی'
    ) AS likely_cancel_reason_fa,
    multiIf(
        NOT has_specific_reason_evidence AND all_vendors_excellent, 'excellent_vendor_light_monitoring',
        NOT has_specific_reason_evidence, 'general_monitoring_queue',
        max_reason_score = customer_intent_reason_score, 'customer_retention_queue',
        max_reason_score = vendor_no_approval_reason_score, 'vendor_approval_queue',
        max_reason_score = inventory_reason_score, 'inventory_recovery_queue',
        max_reason_score = delay_reason_score, 'shipping_followup_queue',
        max_reason_score = price_reason_score, 'price_resolution_queue',
        'general_monitoring_queue'
    ) AS action_queue,
    arrayStringConcat(
        arrayFilter(
            evidence -> evidence != '',
            [
                if(has_active_cancel_request, 'درخواست کنسلی فعال ثبت شده', ''),
                if(order_age_hours >= 6 AND order_age_hours < 24 AND has_unapproved_open_item, 'پس از ۶ ساعت هنوز تأیید غرفه‌دار کامل نیست', ''),
                if(order_age_hours >= 6 AND order_age_hours < 24 AND has_unseen_open_item, 'پس از ۶ ساعت بخشی از سفارش دیده نشده', ''),
                if(order_age_hours >= 72 AND has_unsent_open_item, 'پس از ۷۲ ساعت بخشی از سفارش ارسال نشده', ''),
                if(is_past_preparation_sla, 'حداقل یک آیتم از موعد آماده‌سازی خود عبور کرده', ''),
                if(has_problem, 'برای حداقل یک آیتم باز، مشکل ثبت شده است', ''),
                if(has_unanswered_customer_chat, 'آخرین پیام مشتری بدون پاسخ غرفه‌دار مانده', ''),
                if(cancel_keyword_messages > 0, 'در چت درباره لغو یا کنسلی صحبت شده', ''),
                if(explicit_cancel_phrase_messages > 0, 'عبارت صریح درخواست لغو در چت دیده شده', ''),
                if(inventory_keyword_messages > 0, 'در چت درباره موجودی صحبت شده', ''),
                if(explicit_stockout_phrase_messages > 0, 'عبارت صریح ناموجود یا تمام‌شدن کالا در چت دیده شده', ''),
                if(vendor_inability_phrase_messages > 0, 'غرفه‌دار در چت از ناتوانی یا مشکل انجام سفارش گفته', ''),
                if(no_send_or_no_response_phrase_messages > 0, 'در چت نشانه عدم ارسال یا عدم پاسخ دیده شده', ''),
                if(replacement_or_change_phrase_messages > 0, 'در چت درباره تغییر یا جایگزینی کالا صحبت شده', ''),
                if(has_current_stock_problem OR has_current_unavailable_product, 'محصول در وضعیت فعلی مشکل موجودی/دسترسی دارد', ''),
                if(has_missing_product_state, 'وضعیت فعلی حداقل یک محصول در بعد محصول پیدا نشد', ''),
                if(NOT business_value_eligible, 'سفارش زیر کف ارزش تجاری GMV/commission قرار دارد', ''),
                if(max_vendor_cancel_rate >= 0.20, 'سابقه کنسلی غرفه بالا است', ''),
                if(max_vendor_no_approve_rate >= 0.05, 'سابقه عدم تأیید غرفه بالا است', ''),
                if(shipping_keyword_messages > 0, 'در چت درباره ارسال یا تأخیر صحبت شده', ''),
                if(price_keyword_messages > 0, 'در چت درباره قیمت صحبت شده', '')
            ]
        ),
        ' | '
    ) AS evidence_summary_fa,
    multiIf(
        has_active_cancel_request AND business_value_eligible, 'تماس فوری با مشتری و بررسی امکان حفظ سفارش',
        has_active_cancel_request, 'پیام خودکار فوری و بررسی درخواست کنسلی',
        explicit_cancel_phrase_messages > 0 AND business_value_eligible, 'بررسی فوری چت و تماس با مشتری برای جلوگیری از لغو',
        explicit_cancel_phrase_messages > 0, 'پیام خودکار حفظ سفارش و بررسی چت',
        explicit_stockout_phrase_messages > 0, 'تأیید فوری موجودی و پیشنهاد کالای جایگزین',
        has_unanswered_customer_chat, 'پیگیری پاسخ غرفه‌دار به مشتری',
        order_age_hours >= 6 AND order_age_hours < 24 AND has_unapproved_open_item, 'پیگیری تأیید سفارش از غرفه‌دار',
        has_current_stock_problem OR has_current_unavailable_product, 'تأیید موجودی و بررسی کالای جایگزین',
        is_past_preparation_sla OR (order_age_hours >= 72 AND has_unsent_open_item), 'پیگیری فوری آماده‌سازی و ارسال از غرفه‌دار',
        priority_0_1 >= 0.95 AND business_value_eligible, 'تماس فعال برای حفظ سفارش با ارزش اقتصادی بالا',
        priority_0_1 >= 0.85 AND business_value_eligible, 'پایش نزدیک و پیگیری فعال سفارش با ارزش',
        dynamic_cancel_probability >= 0.40, 'مداخله خودکار برای سفارش پرریسک با ارزش پایین‌تر',
        all_vendors_excellent AND NOT has_specific_reason_evidence, 'پایش سبک خودکار؛ غرفه‌ها در سطح عالی هستند',
        'پایش عادی'
    ) AS recommended_action_fa,
    has_unseen_open_item,
    has_unapproved_open_item,
    has_unsent_open_item,
    has_active_cancel_request,
    has_problem,
    is_past_preparation_sla,
    has_missing_product_state,
    has_specific_reason_evidence,
    has_unanswered_customer_chat,
    chat_messages,
    customer_chat_messages,
    vendor_chat_messages,
    cancel_keyword_messages,
    inventory_keyword_messages,
    shipping_keyword_messages,
    price_keyword_messages,
    explicit_cancel_phrase_messages,
    explicit_stockout_phrase_messages,
    vendor_inability_phrase_messages,
    no_send_or_no_response_phrase_messages,
    replacement_or_change_phrase_messages,
    round(100.0 * max_vendor_cancel_rate, 2) AS max_vendor_historical_cancel_rate_pct,
    round(100.0 * max_vendor_no_approve_rate, 2) AS max_vendor_historical_no_approve_rate_pct,
    round(100.0 * max_vendor_out_of_stock_rate, 2) AS max_vendor_historical_oos_rate_pct,
    round(100.0 * gmv_percentile_0_1, 2) AS gmv_percentile_pct,
    round(100.0 * commission_amount_percentile_0_1, 2) AS commission_amount_percentile_pct,
    round(100.0 * commission_rate_score_0_1, 2) AS commission_rate_score_pct,
    round(100.0 * expected_gmv_loss_percentile_0_1, 2) AS expected_gmv_loss_percentile_pct,
    round(100.0 * expected_commission_loss_percentile_0_1, 2) AS expected_commission_loss_percentile_pct,
    round(base_risk_raw, 6) AS base_risk_raw,
    round(evidence_odds_multiplier, 2) AS evidence_odds_multiplier,
    'live_priority_v4_1_value_aware_2026_08_01' AS model_version
FROM final_scored
ORDER BY priority_pct DESC, cancellation_probability_pct DESC, order_gmv_toman DESC;
