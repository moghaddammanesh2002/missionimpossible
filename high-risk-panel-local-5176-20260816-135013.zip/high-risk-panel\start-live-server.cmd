@echo off
cd /d "%~dp0"
set PORT=5176
set HIGH_RISK_DATE_FILTER=today
set HIGH_RISK_TIMEZONE=Asia/Tehran
echo Starting High Risk live panel on http://127.0.0.1:%PORT%/
echo Logs: %~dp0live-server.log
start "" "http://127.0.0.1:%PORT%/"
"C:\Users\surface\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" server.js > live-server.log 2>&1
echo.
echo Server stopped. Check live-server.log for details.
pause
